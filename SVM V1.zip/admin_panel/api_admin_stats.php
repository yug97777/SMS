<?php
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    echo json_encode(["status" => "error", "message" => "Unauthenticated access."]);
    exit;
}

include 'db.php';

// Stats logic
$counts = [
    'students' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM students"))['c'],
    'teachers' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM teachers"))['c'],
    'parents' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM parents"))['c'],
    'unpaid_fees' => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM fees WHERE status='PENDING'"))['c']
];

// Recent Activities
$activities = [];
$res = mysqli_query($conn, "SELECT m.title, m.created_at, u.name FROM study_materials m JOIN users u ON m.uploaded_by = u.id ORDER BY m.created_at DESC LIMIT 5");
while($r = mysqli_fetch_assoc($res)) {
    $activities[] = "Material '{$r['title']}' uploaded by Teacher {$r['name']}";
}

echo json_encode([
    "status" => "success",
    "stats" => $counts,
    "activities" => $activities,
    "user" => [
        "name" => $_SESSION['name'],
        "id" => $_SESSION['user_id']
    ]
]);
?>
