<?php
header('Content-Type: application/json');
session_start();

// Admin or Teacher protection
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['ADMIN', 'TEACHER'])) {
    echo json_encode(["status" => "error", "message" => "Unauthorized access."]);
    exit;
}

include 'db.php';

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

if ($action === 'list_users') {
    $res = mysqli_query($conn, "SELECT id, name, role FROM users WHERE status=1 ORDER BY role, name ASC");
    $list = [];
    while($r = mysqli_fetch_assoc($res)) $list[] = $r;
    echo json_encode(["status" => "success", "data" => $list]);
    exit;
}
else if ($action === 'list') {
    // Fetch last 20 notifications
    $query = "SELECT * FROM notifications ORDER BY created_at DESC LIMIT 20";
    $result = mysqli_query($conn, $query);
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $row['formatted_date'] = date("d M Y, h:i A", strtotime($row['created_at']));
        $data[] = $row;
    }
    echo json_encode(["status" => "success", "data" => $data]);
} 
else if ($action === 'send') {
    $title   = mysqli_real_escape_string($conn, trim($_POST['title'] ?? ''));
    $message = mysqli_real_escape_string($conn, trim($_POST['message'] ?? ''));
    $role    = mysqli_real_escape_string($conn, $_POST['role'] ?? 'ALL');

    if (empty($title) || empty($message)) {
        echo json_encode(["status" => "error", "message" => "Title and Message are required."]);
        exit;
    }

    $stmt = mysqli_prepare($conn, "INSERT INTO notifications (title, message, role, status) VALUES (?, ?, ?, 'UNREAD')");
    mysqli_stmt_bind_param($stmt, "sss", $title, $message, $role);
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(["status" => "success", "message" => "Notification dispatched!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Dispatch failed."]);
    }
}
else if ($action === 'delete') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        mysqli_query($conn, "DELETE FROM notifications WHERE id = $id");
        echo json_encode(["status" => "success", "message" => "Deleted."]);
    }
}
else {
    echo json_encode(["status" => "error", "message" => "Invalid action."]);
}
?>
