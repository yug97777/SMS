<?php
session_start();
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['ADMIN', 'TEACHER'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Broadcast Center | School Notifications</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #f97316;
            --primary-dark: #ea580c;
            --bg-color: #fffaf5;
            --glass: rgba(255, 255, 255, 0.7);
            --glass-border: rgba(255, 255, 255, 0.2);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Outfit', sans-serif; }

        body {
            background-color: var(--bg-color);
            background-image: 
                radial-gradient(at 100% 0%, rgba(249, 115, 22, 0.08) 0px, transparent 50%),
                radial-gradient(at 0% 100%, rgba(249, 115, 22, 0.05) 0px, transparent 50%);
            min-height: 100vh;
            color: #1e293b;
            padding: 30px;
        }

        /* Nav */
        header { max-width: 1200px; margin: 0 auto 40px; display: flex; justify-content: space-between; align-items: center; }
        .logo { font-size: 28px; font-weight: 800; color: var(--primary-dark); display: flex; align-items: center; gap: 15px; }
        .logo i { background: var(--primary); color: white; width: 45px; height: 45px; border-radius: 14px; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 20px rgba(249, 115, 22, 0.25); }

        .container { max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: 1fr 1.50fr; gap: 40px; }

        /* Card System */
        .card {
            background: var(--glass);
            backdrop-filter: blur(25px);
            border: 1px solid var(--glass-border);
            border-radius: 35px;
            padding: 40px;
            box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.05);
            animation: slideIn 0.7s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes slideIn { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }

        h2 { font-size: 24px; font-weight: 800; margin-bottom: 25px; display: flex; align-items: center; gap: 12px; }
        h2 i { color: var(--primary); }

        /* Form */
        .form-group { margin-bottom: 25px; }
        label { display: block; font-size: 13px; font-weight: 700; color: #64748b; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px; }
        
        .input-wrapper { position: relative; }
        .input-wrapper i { position: absolute; left: 18px; top: 50%; transform: translateY(-50%); color: #94a3b8; }

        input, textarea, select {
            width: 100%; padding: 16px 16px 16px 50px;
            background: white; border: 2px solid #f1f5f9; border-radius: 20px;
            font-size: 15px; color: #1e293b; outline: none; transition: 0.3s;
        }
        input:focus, textarea:focus, select:focus { border-color: var(--primary); box-shadow: 0 0 0 5px rgba(249, 115, 22, 0.1); }
        textarea { padding-left: 20px; resize: none; min-height: 120px; }

        .btn-send {
            width: 100%; padding: 20px; border-radius: 20px; font-weight: 800; border: none; cursor: pointer; transition: 0.3s;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%); color: white;
            display: flex; align-items: center; justify-content: center; gap: 12px; margin-top: 15px;
            box-shadow: 0 15px 30px -5px rgba(249, 115, 22, 0.4);
        }
        .btn-send:hover { transform: translateY(-3px); box-shadow: 0 20px 40px -5px rgba(249, 115, 22, 0.5); }
        .btn-send:disabled { opacity: 0.7; cursor: not-allowed; }

        /* History List */
        .history-list { display: flex; flex-direction: column; gap: 15px; }
        .notify-item {
            background: white; border: 1.5px solid #f1f5f9; border-radius: 22px; padding: 20px;
            display: flex; gap: 20px; transition: 0.3s;
        }
        .notify-item:hover { transform: scale(1.02); box-shadow: 0 10px 30px rgba(0,0,0,0.02); }
        
        .icon-circle {
            width: 45px; height: 45px; border-radius: 12px; background: #fff7ed; color: var(--primary);
            display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0;
        }

        .notify-content { flex: 1; }
        .notify-content h4 { font-size: 16px; font-weight: 800; color: #1e293b; margin-bottom: 5px; }
        .notify-content p { font-size: 14px; color: #64748b; line-height: 1.5; }
        .notify-footer { display: flex; justify-content: space-between; margin-top: 12px; align-items: flex-end; }
        .notify-meta { font-size: 11px; font-weight: 700; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px; display: flex; gap: 10px; }
        .notify-tag { padding: 4px 10px; border-radius: 8px; font-size: 10px; font-weight: 800; background: #f1f5f9; color: #475569; }

        .btn-delete { background: none; border: none; color: #f43f5e; opacity: 0.3; cursor: pointer; transition: 0.2s; padding: 5px; }
        .btn-delete:hover { opacity: 1; }

        #toast {
            position: fixed; top: 40px; right: 40px; padding: 20px 30px; border-radius: 22px;
            background: white; border: 1px solid var(--primary); color: var(--primary-dark); font-weight: 800;
            box-shadow: 0 25px 50px rgba(249, 115, 22, 0.1); display: none; z-index: 1000; animation: pop 0.4s ease;
        }
        @keyframes pop { from { scale: 0.8; opacity: 0; transform: translateY(-20px); } to { scale: 1; opacity: 1; transform: translateY(0); } }

        @media (max-width: 900px) { .container { grid-template-columns: 1fr; } }
    </style>
</head>
<body>

    <header>
        <div class="logo">
            <i class="fas fa-bullhorn rotate-[-15deg]"></i>
            Broadcast Center
        </div>
        <a href="admin_dashboard.php" style="text-decoration: none; color: #64748b; font-weight: 800; font-size: 14px;"><i class="fas fa-arrow-left"></i> Home</a>
    </header>

    <div class="container">
        <!-- Send Form -->
        <div class="card">
            <h2><i class="fas fa-paper-plane"></i> Dispatch Alert</h2>
            <form id="msgForm">
                <div class="form-group">
                    <label>Broadcast Title</label>
                    <div class="input-wrapper">
                        <i class="fas fa-heading"></i>
                        <input type="text" name="title" placeholder="School Holiday Notice / Fee Reminder" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Target Audience</label>
                    <div class="input-wrapper">
                        <i class="fas fa-users"></i>
                        <select name="role" required>
                            <option value="ALL">Everyone</option>
                            <option value="STUDENT">Students Only</option>
                            <option value="PARENT">Parents Only</option>
                            <option value="TEACHER">Staff Members</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>Broadcast Message</label>
                    <textarea name="message" placeholder="Type your detailed notice here..." required></textarea>
                </div>

                <button type="submit" class="btn-send" id="sendBtn">
                    <i class="fas fa-satellite-dish"></i> Broadcast Now
                </button>
            </form>
        </div>

        <!-- History -->
        <div>
            <h2 style="margin-bottom: 25px;">Recently Published</h2>
            <div class="history-list" id="notify-list">
                <!-- AJAX CONTENT -->
                <div style="padding: 50px; text-align: center; color: #94a3b8;">
                    <i class="fas fa-spinner fa-spin fa-2x"></i>
                </div>
            </div>
        </div>
    </div>

    <div id="toast">Broadcast Dispatched Successfully!</div>

    <script>
        const form = document.getElementById('msgForm');
        const list = document.getElementById('notify-list');
        const btn = document.getElementById('sendBtn');
        const toast = document.getElementById('toast');

        async function fetchNotifications() {
            try {
                const res = await fetch('api_notifications.php?action=list');
                const result = await res.json();
                
                if (result.status === 'success') {
                    if (result.data.length === 0) {
                        list.innerHTML = '<div style="padding: 50px; text-align: center; color: #94a3b8;">No broadcasts recorded.</div>';
                        return;
                    }

                    list.innerHTML = result.data.map(n => `
                        <div class="notify-item">
                            <div class="icon-circle">
                                <i class="fas fa-bell"></i>
                            </div>
                            <div class="notify-content">
                                <h4>${n.title}</h4>
                                <p>${n.message}</p>
                                <div class="notify-footer">
                                    <div class="notify-meta">
                                        <span><i class="far fa-clock"></i> ${n.formatted_date}</span>
                                        <span class="notify-tag">${n.role}</span>
                                    </div>
                                    <button class="btn-delete" onclick="deleteNotify(${n.id})" title="Purge Record"><i class="fas fa-trash-alt"></i></button>
                                </div>
                            </div>
                        </div>
                    `).join('');
                }
            } catch (e) {
                list.innerHTML = '<div style="padding: 50px; text-align: center; color: red;">Network sync failure.</div>';
            }
        }

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-sync fa-spin"></i> BROADCASTING...';

            const formData = new FormData(form);
            formData.append('action', 'send');

            try {
                const res = await fetch('api_notifications.php', { method: 'POST', body: formData });
                const result = await res.json();

                if (result.status === 'success') {
                    showToast();
                    form.reset();
                    fetchNotifications();
                } else {
                    alert(result.message);
                }
            } catch (e) {
                alert("Critical server error.");
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-satellite-dish"></i> Broadcast Now';
            }
        });

        async function deleteNotify(id) {
            if(!confirm('Delete this broadcast record?')) return;
            const fd = new FormData();
            fd.append('action', 'delete');
            fd.append('id', id);
            await fetch('api_notifications.php', { method: 'POST', body: fd });
            fetchNotifications();
        }

        function showToast() {
            toast.style.display = 'block';
            setTimeout(() => toast.style.display = 'none', 4000);
        }

        fetchNotifications();
    </script>
</body>
</html>
