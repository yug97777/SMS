<?php
session_start();
include 'db.php';

/* 🔒 Access Control */
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['STUDENT', 'PARENT'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// Fetch attendance
if ($role === 'STUDENT') {
    $stmt = mysqli_prepare($conn, "
        SELECT a.date, a.status
        FROM attendance a
        JOIN students s ON a.student_id = s.id
        WHERE s.user_id = ?
        ORDER BY a.date DESC
    ");
} else {
    $stmt = mysqli_prepare($conn, "
        SELECT a.date, a.status
        FROM attendance a
        JOIN parents p ON a.student_id = p.student_id
        WHERE p.user_id = ?
        ORDER BY a.date DESC
    ");
}

mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$q = mysqli_stmt_get_result($stmt);

if(!$q){
    die("Database Error");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Attendance History</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>

<body class="bg-gradient-to-br from-indigo-50 to-blue-100 min-h-screen">

<!-- NAVBAR -->
<div class="bg-white shadow px-8 py-4 flex justify-between items-center">
    <h1 class="text-2xl font-bold text-indigo-600 flex items-center gap-2">
        📅 <?= ($role === 'PARENT') ? "Child's Attendance" : "My Attendance" ?>
    </h1>
    <a href="<?= ($role==='PARENT')?'parent_dashboard.php':'student_dashboard.php' ?>"
       class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition">
        Dashboard
    </a>
</div>

<!-- MAIN -->
<div class="max-w-5xl mx-auto px-6 py-10">
    <div class="bg-white rounded-3xl shadow-xl p-8">
        <h2 class="text-xl font-bold text-gray-800 mb-6 font-serif">Historical Records</h2>
        
        <div class="overflow-x-auto">
            <table class="w-full border rounded-xl overflow-hidden">
                <thead>
                    <tr class="bg-indigo-600 text-white text-left">
                        <th class="p-4">Date</th>
                        <th class="p-4 text-center">Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php if(mysqli_num_rows($q) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($q)): ?>
                        <tr class="border-b hover:bg-indigo-50 transition">
                            <td class="p-4 text-gray-700 font-medium">
                                <?= date('d M Y', strtotime($row['date'])) ?>
                            </td>
                            <td class="p-4 text-center font-bold">
                                <?php if($row['status'] === 'P'): ?>
                                    <span class="px-4 py-1 rounded-full bg-green-100 text-green-700">Present</span>
                                <?php else: ?>
                                    <span class="px-4 py-1 rounded-full bg-red-100 text-red-700">Absent</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="2" class="p-8 text-center text-gray-400 italic">No attendance records discovered yet.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<footer class="text-center text-gray-500 text-sm py-8">
    © <?= date('Y') ?> School Management Intelligence
</footer>

</body>
</html>
