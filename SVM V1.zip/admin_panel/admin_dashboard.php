<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: index.php");
    exit;
}
include 'includes/header.php'; 
?>

<!-- MAIN CONTENT (Already started in header.php) -->
<div id="loader" class="shimmer">
    <div class="shimmer-logo"></div>
    <p style="font-weight: 800; color: #94a3b8; text-transform: uppercase; letter-spacing: 2px; font-size: 12px;">Syncing Portal Data</p>
</div>

<!-- STATS -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon" style="background:#eff6ff; color:#3b82f6;"><i class="fas fa-user-graduate"></i></div>
        <span class="stat-label">Enrolled Students</span>
        <div class="stat-value" id="countStudents">0</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#fdf2f7; color:#ec4899;"><i class="fas fa-chalkboard-user"></i></div>
        <span class="stat-label">Faculty Members</span>
        <div class="stat-value" id="countTeachers">0</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#f0fdf4; color:#10b981;"><i class="fas fa-ring"></i></div>
        <span class="stat-label">Parents Network</span>
        <div class="stat-value" id="countParents">0</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:#fffbeb; color:#f59e0b;"><i class="fas fa-credit-card"></i></div>
        <span class="stat-label">Unpaid Fees</span>
        <div class="stat-value" id="countVouchers">0</div>
    </div>
</div>

<div class="data-layout">
    <div class="card-box">
        <div class="card-head">
            <h3>Recent System Activities</h3>
            <a href="#" class="btn-mini">View Full History</a>
        </div>
        <div id="activityList" style="display:flex; flex-direction:column; gap:20px;">
             <p style="text-align: center; padding: 40px; color: #94a3b8; font-weight: 700;">Scanning system logs...</p>
        </div>
    </div>

    <div class="card-box">
        <div class="card-head">
            <h3>Quick Actions</h3>
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
            <a href="mark_attendance.php" style="text-decoration:none; text-align:center; padding:25px; background:#f8fafc; border-radius:20px; color:#64748b; font-weight:800; font-size:13px; transition:0.3s;">
                <i class="fas fa-clipboard-check" style="display:block; font-size:24px; margin-bottom:10px; color:#475569;"></i> Attendance
            </a>
            <a href="send_notification.php" style="text-decoration:none; text-align:center; padding:25px; background:#f8fafc; border-radius:20px; color:#64748b; font-weight:800; font-size:13px; transition:0.3s;">
                <i class="fas fa-bullhorn" style="display:block; font-size:24px; margin-bottom:10px; color:#475569;"></i> Broadcast
            </a>
            <a href="admin_results.php" style="text-decoration:none; text-align:center; padding:25px; background:#f8fafc; border-radius:20px; color:#64748b; font-weight:800; font-size:13px; transition:0.3s;">
                <i class="fas fa-chart-line" style="display:block; font-size:24px; margin-bottom:10px; color:#475569;"></i> Results
            </a>
            <a href="fees_management.php" style="text-decoration:none; text-align:center; padding:25px; background:#f8fafc; border-radius:20px; color:#64748b; font-weight:800; font-size:13px; transition:0.3s;">
                <i class="fas fa-receipt" style="display:block; font-size:24px; margin-bottom:10px; color:#475569;"></i> Receipts
            </a>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', async () => {
    try {
        // Pointing to new API path
        const statsRes = await fetch('api/api_admin_stats.php');
        const data = await statsRes.json();

        if (data.status === 'success') {
            document.getElementById('countStudents').innerText = data.stats.students;
            document.getElementById('countTeachers').innerText = data.stats.teachers;
            document.getElementById('countParents').innerText = data.stats.parents;
            document.getElementById('countVouchers').innerText = data.stats.unpaid_fees;

            const list = document.getElementById('activityList');
            list.innerHTML = '';
            
            if (data.activities.length === 0) {
                list.innerHTML = '<p style="text-align: center; padding: 40px; color: #94a3b8; font-weight: 700;">No recent activity logs.</p>';
            } else {
                data.activities.forEach(act => {
                    const item = document.createElement('div');
                    item.style.cssText = 'padding:10px 15px; background:#f8fafc; border-radius:15px; border-left:4px solid #4f46e5;';
                    item.innerHTML = `<span style="font-size:11px; font-weight:800; color:#94a3b8;">ACTIVITY LOG</span><p style="font-size:14px; font-weight:600; color:#1e293b; margin-top:4px;">${act}</p>`;
                    list.appendChild(item);
                });
            }
        }
    } catch (err) {
        console.error("Dashboard engine error:", err);
    }
});
</script>

<?php include 'includes/footer.php'; ?>
