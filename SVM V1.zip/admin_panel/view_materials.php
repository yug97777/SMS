<?php
session_start();
include 'db.php';

// 🔒 Access Control: Anyone logged in can view
if (!isset($_SESSION['role'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

// Fetch materials with search/filter if needed
$search = trim($_POST['search'] ?? '');
$class_filter = trim($_POST['class_filter'] ?? '');

$sql = "SELECT m.*, u.name as teacher_name 
        FROM study_materials m 
        JOIN users u ON m.uploaded_by = u.id";

$params = [];
$types = "";

if ($search || $class_filter) {
    $sql .= " WHERE ";
    $conditions = [];
    if ($search) {
        $conditions[] = "(title LIKE ? OR subject LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $types .= "ss";
    }
    if ($class_filter) {
        $conditions[] = "class LIKE ?";
        $params[] = "%$class_filter%";
        $types .= "s";
    }
    $sql .= implode(" AND ", $conditions);
}

$sql .= " ORDER BY m.created_at DESC";

if ($params) {
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $materials_res = mysqli_stmt_get_result($stmt);
} else {
    $materials_res = mysqli_query($conn, $sql);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Study Materials Repository</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 24px;
        }
        .material-card:hover .icon-bounce {
            animation: bounce 1s infinite;
        }
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 to-indigo-50 min-h-screen">

<nav class="bg-white/80 backdrop-blur-md sticky top-0 z-50 shadow-sm px-8 py-4 flex justify-between items-center border-b border-indigo-100">
    <div class="flex items-center gap-3">
        <div class="bg-indigo-600 p-2 rounded-xl text-white shadow-lg shadow-indigo-200">
            <i class="fas fa-graduation-cap"></i>
        </div>
        <h1 class="text-xl font-bold bg-gradient-to-r from-indigo-800 to-blue-800 bg-clip-text text-transparent">Learning Center</h1>
    </div>

    <?php 
        $dashboard_link = ($role === 'ADMIN') ? 'admin_dashboard.php' : (($role === 'TEACHER') ? 'teacher_dashboard.php' : (($role === 'PARENT') ? 'parent_dashboard.php' : 'student_dashboard.php'));
    ?>
    <a href="<?= $dashboard_link ?>" class="px-6 py-2 bg-indigo-600 font-bold text-white rounded-xl hover:bg-indigo-700 transition flex items-center gap-2">
        <i class="fas fa-home"></i> Home
    </a>
</nav>

<main class="max-w-7xl mx-auto py-12 px-6">
    <div class="mb-12 text-center max-w-2xl mx-auto">
        <h2 class="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight">Academic Resources</h2>
        <p class="text-lg text-gray-600 leading-relaxed">Access high-quality study materials, chapter notes, and research documents shared by your educators.</p>
    </div>

    <!-- Search/Filter -->
    <form method="POST" class="bg-white p-6 rounded-3xl shadow-sm border border-indigo-50 flex flex-col md:flex-row gap-4 mb-12 items-end">
        <div class="flex-1">
            <label class="block text-sm font-bold text-gray-400 mb-2 uppercase tracking-widest px-1">Keyword Search</label>
            <div class="relative">
                <i class="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                <input type="text" name="search" placeholder="Search by topic or subject..." value="<?= htmlspecialchars($search) ?>"
                    class="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition">
            </div>
        </div>
        <div class="w-full md:w-64">
            <label class="block text-sm font-bold text-gray-400 mb-2 uppercase tracking-widest px-1">Subject/Class Filter</label>
            <input type="text" name="class_filter" placeholder="Filter by class..." value="<?= htmlspecialchars($class_filter) ?>"
                class="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none transition uppercase font-semibold text-gray-600">
        </div>
        <button type="submit" class="px-10 py-3 bg-white text-indigo-600 font-bold border-2 border-indigo-600 rounded-2xl hover:bg-indigo-600 hover:text-white transition">
            Filter
        </button>
    </form>

    <div class="grid-container">
        <?php if(mysqli_num_rows($materials_res) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($materials_res)): ?>
                <div class="material-card bg-white rounded-3xl p-6 shadow-sm border border-transparent hover:border-indigo-200 hover:shadow-xl hover:shadow-indigo-100/50 transition-all duration-300 group flex flex-col">
                    <div class="flex justify-between items-start mb-4">
                        <div class="p-3 bg-indigo-50 rounded-2xl group-hover:bg-indigo-600 transition-colors duration-300">
                            <i class="fas fa-file-pdf text-indigo-600 text-2xl group-hover:text-white transition-colors duration-300 icon-bounce"></i>
                        </div>
                        <span class="text-xs font-bold text-indigo-600 bg-indigo-50 border border-indigo-100 px-3 py-1 rounded-full uppercase tracking-tighter">
                            <?= htmlspecialchars($row['class']) ?>
                        </span>
                    </div>

                    <h3 class="text-xl font-bold text-gray-800 mb-2 line-clamp-2"><?= htmlspecialchars($row['title']) ?></h3>
                    <p class="text-gray-500 text-sm mb-6 flex-1 line-clamp-3 leading-relaxed">
                        <?= htmlspecialchars($row['description']) ?: 'No extra details provided.' ?>
                    </p>

                    <div class="pt-6 mt-6 border-t border-gray-50 flex items-end justify-between gap-4">
                        <div class="min-w-0">
                            <span class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 px-1">Educator</span>
                            <div class="flex items-center gap-2">
                                <img src="https://ui-avatars.com/api/?name=<?= urlencode($row['teacher_name']) ?>&background=random" class="w-6 h-6 rounded-lg">
                                <span class="text-sm font-semibold text-gray-700 truncate"><?= htmlspecialchars($row['teacher_name']) ?></span>
                            </div>
                        </div>
                        <a href="<?= $row['file_path'] ?>" download class="w-12 h-12 flex items-center justify-center bg-gray-50 text-gray-400 rounded-2xl hover:bg-indigo-600 hover:text-white hover:shadow-lg hover:shadow-indigo-200 transition-all active:scale-90">
                            <i class="fas fa-download"></i>
                        </a>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-span-full py-24 text-center bg-white rounded-3xl border-2 border-dashed border-gray-100">
                <i class="fas fa-box-open text-gray-200 text-6xl mb-6"></i>
                <h3 class="text-2xl font-bold text-gray-400">No resources found matching the criteria.</h3>
                <p class="text-gray-400 mt-2">Try adjusting your filters or check back later.</p>
            </div>
        <?php endif; ?>
    </div>
</main>

<footer class="text-center py-12 text-gray-400 text-sm font-medium">
    &copy; <?= date('Y') ?> Advanced School Management Systems - Resource Portal
</footer>

</body>
</html>
