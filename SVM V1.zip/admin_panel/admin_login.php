<?php
session_start();
header('Content-Type: application/json');

include 'db.php';

// Handle POST (AJAX login)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username === '' || $password === '') {
        echo json_encode([
            "status" => "error",
            "message" => "Username or Password missing"
        ]);
        exit;
    }

    // Secure query: Fetch by email first
    $stmt = mysqli_prepare(
        $conn,
        "SELECT id, name, role, password FROM users 
         WHERE email = ? AND status = 1"
    );
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) === 1) {

        $user = mysqli_fetch_assoc($result);

        // Verify hashed password
        if (password_verify($password, $user['password'])) {

            // Set session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role']    = $user['role'];
            $_SESSION['name']    = $user['name'];

            // Role-based redirect
            switch ($user['role']) {
                case 'ADMIN':
                    $redirect = "admin_dashboard.php";
                    break;
                case 'TEACHER':
                    $redirect = "teacher_dashboard.php";
                    break;
                case 'STUDENT':
                    $redirect = "student_dashboard.php";
                    break;
                case 'PARENT':
                    $redirect = "parent_dashboard.php";
                    break;
                default:
                    session_destroy();
                    $redirect = "index.php";
            }

            echo json_encode([
                "status"   => "success",
                "redirect" => $redirect
            ]);
            exit;
        }
    }

    // Default error response
    echo json_encode([
        "status" => "error",
        "message" => "Invalid Username or Password"
    ]);
    exit;
}
?>
