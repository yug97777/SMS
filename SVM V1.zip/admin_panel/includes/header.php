<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SVM Sancul | System</title>
    <!-- Google Fonts & FontAwesome -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <!-- Shared Styles -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <!-- SIDEBAR -->
    <div class="sidebar">
        <div class="brand">
            <div class="brand-logo"><i class="fas fa-landmark"></i></div>
            <span class="brand-name">SVM Sancul</span>
        </div>

        <div class="nav-label">Management Engine</div>
        <ul class="nav-links">
            <li style="width:100%"><a href="admin_dashboard.php" class="nav-link <?= $current_page == 'admin_dashboard.php' ? 'active' : '' ?>"><i class="fas fa-layer-group"></i> Dashboard Overview</a></li>
            <li style="width:100%"><a href="students_list.php" class="nav-link <?= $current_page == 'students_list.php' ? 'active' : '' ?>"><i class="fas fa-user-graduate"></i> Manage Students</a></li>
            <li style="width:100%"><a href="register_teacher.php" class="nav-link <?= $current_page == 'register_teacher.php' ? 'active' : '' ?>"><i class="fas fa-id-badge"></i> Educator Registry</a></li>
            <li style="width:100%"><a href="parent_management.php" class="nav-link <?= $current_page == 'parent_management.php' ? 'active' : '' ?>"><i class="fas fa-users-viewfinder"></i> Parent Relations</a></li>
        </ul>

        <div class="nav-label">Academic Ops</div>
        <ul class="nav-links">
            <li style="width:100%"><a href="mark_attendance.php" class="nav-link <?= $current_page == 'mark_attendance.php' ? 'active' : '' ?>"><i class="fas fa-calendar-check"></i> Attendance Matrix</a></li>
            <li style="width:100%"><a href="admin_results.php" class="nav-link <?= $current_page == 'admin_results.php' ? 'active' : '' ?>"><i class="fas fa-medal"></i> Examination Ledger</a></li>
            <li style="width:100%"><a href="fees_management.php" class="nav-link <?= $current_page == 'fees_management.php' ? 'active' : '' ?>"><i class="fas fa-wallet"></i> Finance & Fees</a></li>
            <li style="width:100%"><a href="send_notification.php" class="nav-link <?= $current_page == 'send_notification.php' ? 'active' : '' ?>"><i class="fas fa-paper-plane"></i> Broadcast Center</a></li>
        </ul>

        <div style="margin-top: auto; padding-top: 40px;">
            <a href="logout.php" class="nav-link" style="color: #ef4444; background: rgba(239, 68, 68, 0.05);"><i class="fas fa-sign-out-alt"></i> Secure Log Out</a>
        </div>
    </div>

    <!-- MAIN CONTENT WRAPPER (to be closed in footer) -->
    <main class="main-content">
        <header>
            <div class="welcome-box">
                <h1 id="welcomeTitle">System Panel</h1>
                <p>Strategic control room for Sharda Vidhya Mandir operations.</p>
            </div>
            <div class="user-profile">
                <div class="avatar"><i class="fas fa-shield-halved"></i></div>
                <div>
                    <span style="font-size: 13px; font-weight: 800; display: block; color: #1e293b;" id="topUserName"><?= $_SESSION['name'] ?? 'User' ?></span>
                    <span style="font-size: 11px; font-weight: 700; color: #94a3b8; text-transform: uppercase;"><?= $_SESSION['role'] ?? 'Guest' ?></span>
                </div>
                <i class="fas fa-chevron-down" style="font-size: 12px; color: #94a3b8; margin-left: 10px;"></i>
            </div>
        </header>