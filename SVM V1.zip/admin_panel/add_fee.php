<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: index.php");
    exit;
}

include 'db.php';

// Pre-load students for selection
$students = mysqli_query($conn, "SELECT s.id, u.name, s.roll_no FROM students s JOIN users u ON s.user_id = u.id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Fee | Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; background: #f3f7fa; }
        .glass { background: rgba(255, 255, 255, 0.8); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.4); }
        .loader { width: 18px; height: 18px; border: 3px solid #fff; border-bottom-color: transparent; border-radius: 50%; display: inline-block; animation: rotation 1s linear infinite; }
        @keyframes rotation { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body class="text-slate-900 min-h-screen">

<nav class="bg-white/80 backdrop-blur-md border-b border-slate-200 px-8 py-4 flex justify-between items-center sticky top-0 z-50">
    <div class="flex items-center gap-3">
        <div class="bg-emerald-600 p-2 rounded-xl shadow-lg shadow-emerald-100">
            <i class="fas fa-hand-holding-dollar text-white"></i>
        </div>
        <h1 class="text-xl font-bold tracking-tight">Fee Management</h1>
    </div>
    <a href="fees_management.php" class="px-5 py-2 bg-slate-900 text-white rounded-xl text-sm font-bold shadow-xl shadow-slate-200 hover:-translate-y-0.5 transition-all">Back to Dashboard</a>
</nav>

<div class="max-w-4xl mx-auto py-12 px-6">
    <div class="glass rounded-[2.5rem] shadow-2xl p-10 md:p-16 border border-white">
        <div class="mb-12 text-center md:text-left">
            <h2 class="text-3xl font-extrabold text-slate-800 tracking-tight">Issue New Fee Receipt</h2>
            <p class="text-slate-500 font-medium mt-2">Generate a new outstanding fee record for individual students.</p>
        </div>

        <div id="alertBox" class="hidden mb-10 p-5 rounded-2xl flex items-center gap-3 font-bold text-sm">
            <i id="alertIcon" class="fas"></i>
            <span id="alertMsg"></span>
        </div>

        <form id="feeForm" class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div class="md:col-span-2">
                <label class="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-3 px-1">Target Student</label>
                <select name="student_id" required class="w-full bg-slate-50 border border-slate-100 rounded-2xl p-5 text-sm font-bold focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all outline-none shadow-sm appearance-none cursor-pointer">
                    <option value="">Select a Student...</option>
                    <?php while($s = mysqli_fetch_assoc($students)): ?>
                        <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?> (Roll: <?= $s['roll_no'] ?>)</option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div>
                <label class="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-3 px-1">Amount Due (₹)</label>
                <input type="number" name="amount" placeholder="5000" required class="w-full bg-slate-50 border border-slate-100 rounded-2xl p-5 text-sm font-bold focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all outline-none shadow-sm">
            </div>

            <div>
                <label class="block text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-3 px-1">Payment Due Date</label>
                <input type="date" name="due_date" value="<?= date('Y-m-d') ?>" required class="w-full bg-slate-50 border border-slate-100 rounded-2xl p-5 text-sm font-bold focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all outline-none shadow-sm">
            </div>

            <div class="md:col-span-2 pt-6">
                <button type="submit" id="submitBtn" class="w-full bg-emerald-600 text-white font-black py-6 rounded-2xl shadow-2xl shadow-emerald-200 uppercase tracking-widest text-xs hover:bg-emerald-700 hover:-translate-y-1 transition-all active:scale-95 flex items-center justify-center gap-3">
                    <span id="btnText">Generate Fee Record</span>
                    <span id="btnLoader" class="loader hidden"></span>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    const feeForm = document.getElementById('feeForm');
    const submitBtn = document.getElementById('submitBtn');
    const btnText = document.getElementById('btnText');
    const btnLoader = document.getElementById('btnLoader');
    const alertBox = document.getElementById('alertBox');
    const alertIcon = document.getElementById('alertIcon');
    const alertMsg = document.getElementById('alertMsg');

    feeForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // UI Reset
        alertBox.classList.add('hidden');
        btnText.innerText = 'Processing...';
        btnLoader.classList.remove('hidden');
        submitBtn.disabled = true;

        const formData = new FormData(feeForm);
        formData.append('action', 'save');

        try {
            const res = await fetch('api_fees.php', {
                method: 'POST',
                body: formData
            });
            const result = await res.json();

            if (result.status === 'success') {
                showAlert('success', result.message);
                feeForm.reset();
            } else {
                showAlert('error', result.message);
            }
        } catch (error) {
            showAlert('error', 'Network error occurred.');
        } finally {
            btnText.innerText = 'Generate Fee Record';
            btnLoader.classList.add('hidden');
            submitBtn.disabled = false;
        }
    });

    function showAlert(type, msg) {
        alertBox.classList.remove('hidden', 'bg-emerald-50', 'text-emerald-700', 'border-emerald-100', 'bg-rose-50', 'text-rose-700', 'border-rose-100');
        
        if (type === 'success') {
            alertBox.classList.add('bg-emerald-50', 'text-emerald-700', 'border-emerald-100');
            alertIcon.className = 'fas fa-check-circle';
        } else {
            alertBox.classList.add('bg-rose-50', 'text-rose-700', 'border-rose-100');
            alertIcon.className = 'fas fa-circle-exclamation';
        }
        
        alertMsg.innerText = msg;
    }
</script>

</body>
</html>
