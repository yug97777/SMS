<?php
header('Content-Type: application/json');
session_start();

// Auth check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    echo json_encode(["success" => false, "message" => "Unauthorized access."]);
    exit;
}

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get data (can be from $_POST if using FormData or from php://input if using JSON)
    $name     = mysqli_real_escape_string($conn, trim($_POST['name'] ?? ''));
    $email    = mysqli_real_escape_string($conn, trim($_POST['email'] ?? ''));
    $password_plain = trim($_POST['password'] ?? '');
    $class    = mysqli_real_escape_string($conn, $_POST['class'] ?? '');
    $batch    = mysqli_real_escape_string($conn, $_POST['batch'] ?? '');
    $roll_no  = mysqli_real_escape_string($conn, $_POST['roll_no'] ?? '');

    // Validation
    if (empty($name) || empty($email) || empty($password_plain) || empty($class) || empty($batch) || empty($roll_no)) {
        echo json_encode(["success" => false, "message" => "All fields are required."]);
        exit;
    }

    $password_hash = password_hash($password_plain, PASSWORD_DEFAULT);

    // 🛡️ Use Transaction for integrity
    mysqli_begin_transaction($conn);

    try {
        // 1. Insert into users table
        $stmt_user = mysqli_prepare($conn, "INSERT INTO users (name, email, password, role, status) VALUES (?, ?, ?, 'STUDENT', 1)");
        mysqli_stmt_bind_param($stmt_user, "sss", $name, $email, $password_hash);
        
        if (!mysqli_stmt_execute($stmt_user)) {
            throw new Exception("Email already exists or database error.");
        }

        $user_id = mysqli_insert_id($conn);

        // 2. Insert into students table
        $stmt_student = mysqli_prepare($conn, "INSERT INTO students (user_id, class, batch, roll_no) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt_student, "isss", $user_id, $class, $batch, $roll_no);
        
        if (!mysqli_stmt_execute($stmt_student)) {
            throw new Exception("Failed to create student profile.");
        }

        mysqli_commit($conn);
        echo json_encode(["success" => true, "message" => "Student registered successfully!"]);

    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo json_encode(["success" => false, "message" => $e->getMessage()]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
}
?>
