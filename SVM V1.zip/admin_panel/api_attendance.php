<?php
header('Content-Type: application/json');
session_start();

// Teacher or Admin protection
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'TEACHER' && $_SESSION['role'] !== 'ADMIN')) {
    echo json_encode(["status" => "error", "message" => "Unauthorized access."]);
    exit;
}

include 'db.php';

$action = $_GET['action'] ?? $_POST['action'] ?? 'list_students';

if ($action === 'list_meta') {
    // Get unique classes and batches for dropdowns
    $classes = mysqli_query($conn, "SELECT DISTINCT class FROM students ORDER BY class ASC");
    $batches = mysqli_query($conn, "SELECT DISTINCT batch FROM students ORDER BY batch ASC");
    
    $c_list = []; while($r = mysqli_fetch_assoc($classes)) $c_list[] = $r['class'];
    $b_list = []; while($r = mysqli_fetch_assoc($batches)) $b_list[] = $r['batch'];
    
    echo json_encode([
        "status" => "success",
        "classes" => $c_list,
        "batches" => $b_list
    ]);
    exit;
}

else if ($action === 'list_students') {
    $class = mysqli_real_escape_string($conn, $_POST['class'] ?? '');
    $batch = mysqli_real_escape_string($conn, $_POST['batch'] ?? '');
    
    if (empty($class) || empty($batch)) {
        echo json_encode(["status" => "error", "message" => "Class and Batch required."]);
        exit;
    }

    $query = "
        SELECT 
            students.id,
            users.name
        FROM students
        JOIN users ON students.user_id = users.id
        WHERE students.class='$class'
        AND students.batch='$batch'
        ORDER BY users.name ASC
    ";
    
    $result = mysqli_query($conn, $query);
    $students = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $students[] = $row;
    }
    
    echo json_encode(["status" => "success", "data" => $students]);
} 
else if ($action === 'save') {
    $class = mysqli_real_escape_string($conn, $_POST['class'] ?? '');
    $batch = mysqli_real_escape_string($conn, $_POST['batch'] ?? '');
    $date  = mysqli_real_escape_string($conn, $_POST['date'] ?? date('Y-m-d'));
    $statuses = $_POST['status'] ?? []; // Expected as an array of student_id => status

    if (empty($statuses)) {
        echo json_encode(["status" => "error", "message" => "No attendance data provided."]);
        exit;
    }

    // Begin transaction for safety
    mysqli_begin_transaction($conn);

    try {
        foreach ($statuses as $student_id => $status) {
            $student_id = (int)$student_id;
            $status = mysqli_real_escape_string($conn, $status);
            
            // Check if record exists for this student on this date
            $check = mysqli_query($conn, "SELECT id FROM attendance WHERE student_id=$student_id AND date='$date'");
            
            if (mysqli_num_rows($check) > 0) {
                // Update
                mysqli_query($conn, "UPDATE attendance SET status='$status' WHERE student_id=$student_id AND date='$date'");
            } else {
                // Insert
                mysqli_query($conn, "INSERT INTO attendance (student_id, date, status, class, batch) VALUES ($student_id, '$date', '$status', '$class', '$batch')");
            }
        }
        
        mysqli_commit($conn);
        echo json_encode(["status" => "success", "message" => "Attendance saved successfully!"]);
    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo json_encode(["status" => "error", "message" => "Process failed: " . $e->getMessage()]);
    }
}
else {
    echo json_encode(["status" => "error", "message" => "Invalid action."]);
}
?>
