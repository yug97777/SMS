<?php
session_start();
// Teacher or Admin protection
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'TEACHER' && $_SESSION['role'] !== 'ADMIN')) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Hub | School Management</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link href="https://fonts.googleapis.com/css2?family=Urbanist:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --present: #10b981;
            --absent: #ef4444;
            --glass: rgba(255, 255, 255, 0.75);
            --glass-border: rgba(255, 255, 255, 0.25);
            --bg-gradient: linear-gradient(135deg, #f5f7ff 0%, #e8ecff 100%);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Urbanist', sans-serif; }

        body {
            background: var(--bg-gradient);
            min-height: 100vh;
            color: #1e293b;
            padding: 30px 20px;
        }

        /* Float effects */
        .abstract-obj {
            position: fixed;
            z-index: -1;
            filter: blur(80px);
            border-radius: 50%;
            animation: float 20s infinite alternate;
        }
        .obj1 { width: 300px; height: 300px; background: rgba(99, 102, 241, 0.15); top: -10%; left: -5%; }
        .obj2 { width: 400px; height: 400px; background: rgba(16, 185, 129, 0.1); bottom: -10%; right: -5%; }

        @keyframes float {
            from { transform: translate(0, 0) rotate(0deg); }
            to { transform: translate(50px, 30px) rotate(10deg); }
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Header */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }
        .header-title h1 { font-size: 32px; font-weight: 800; background: linear-gradient(to right, #4f46e5, #9333ea); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; }
        .header-title p { color: #64748b; font-weight: 500; font-size: 16px; margin-top: 5px; }

        /* Filter Section */
        .attendance-card {
            background: var(--glass);
            backdrop-filter: blur(25px);
            border: 1px solid var(--glass-border);
            border-radius: 35px;
            padding: 40px;
            box-shadow: 0 30px 60px -15px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
        }

        .filter-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr) auto;
            gap: 20px;
            align-items: flex-end;
        }

        .input-group label { display: block; font-size: 13px; font-weight: 700; color: #475569; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }
        .input-group select, .input-group input {
            width: 100%;
            padding: 14px 18px;
            border-radius: 18px;
            border: 2px solid #e2e8f0;
            background: white;
            font-size: 15px;
            font-weight: 600;
            outline: none;
            transition: 0.3s;
        }
        .input-group select:focus, .input-group input:focus { border-color: var(--primary); box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1); }

        .btn {
            padding: 14px 28px;
            border-radius: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-size: 15px;
        }

        .btn-load { background: var(--primary); color: white; box-shadow: 0 10px 20px -5px rgba(99, 102, 241, 0.4); }
        .btn-load:hover { transform: translateY(-2px); box-shadow: 0 15px 25px -5px rgba(99, 102, 241, 0.5); }

        /* Listing Area */
        .listing-area { display: none; }

        .bulk-actions {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
            padding: 15px 0;
            border-bottom: 1px solid #e2e8f0;
        }
        .btn-bulk { padding: 10px 20px; border-radius: 14px; font-size: 13px; font-weight: 700; }
        .btn-present { background: #ecfdf5; color: #059669; border: 1.5px solid #10b981; }
        .btn-absent { background: #fef2f2; color: #dc2626; border: 1.5px solid #ef4444; }

        /* Student Table */
        .student-table { width: 100%; border-collapse: separate; border-spacing: 0 10px; }
        .student-table th { text-align: left; padding: 0 20px 10px; color: #64748b; font-size: 12px; text-transform: uppercase; letter-spacing: 1.5px; font-weight: 700; }
        .student-row { background: white; transition: 0.3s; }
        .student-row:hover { transform: scale(1.01); box-shadow: 0 10px 20px -5px rgba(0,0,0,0.05); }
        .student-row td { padding: 18px 20px; border-top: 1px solid #f1f5f9; border-bottom: 1px solid #f1f5f9; }
        .student-row td:first-child { border-left: 1px solid #f1f5f9; border-radius: 20px 0 0 20px; }
        .student-row td:last-child { border-right: 1px solid #f1f5f9; border-radius: 0 20px 20px 0; }

        /* Toggle Switches */
        .toggle-group { display: flex; background: #f1f5f9; padding: 5px; border-radius: 14px; width: fit-content; }
        .toggle-btn {
            padding: 8px 18px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            border: none;
            color: #64748b;
        }
        .toggle-btn.active.P { background: var(--present); color: white; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3); }
        .toggle-btn.active.A { background: var(--absent); color: white; box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3); }

        .btn-save { width: 100%; margin-top: 30px; background: linear-gradient(135deg, #6366f1, #9333ea); color: white; transition: 0.4s; }
        .btn-save:hover { transform: translateY(-3px); box-shadow: 0 15px 35px rgba(99, 102, 241, 0.4); }

        /* Success Toast */
        #toast {
            position: fixed; top: 30px; right: 30px;
            padding: 20px 30px; border-radius: 20px;
            background: white; border: 1px solid #e2e8f0;
            box-shadow: 0 25px 50px -12px rgba(0,0,0,0.1);
            display: flex; align-items: center; gap: 15px;
            transform: translateX(120%); transition: 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            z-index: 2000;
        }
        #toast.show { transform: translateX(0); }
        #toast i { font-size: 24px; color: var(--present); }

        @media (max-width: 768px) {
            .filter-grid { grid-template-columns: 1fr; }
            .btn-load { width: 100%; }
        }
    </style>
</head>
<body>
    <div class="abstract-obj obj1"></div>
    <div class="abstract-obj obj2"></div>

    <div class="container">
        <header>
            <div class="header-title">
                <h1>Attendance Hub</h1>
                <p>Monitor and manage daily student participation.</p>
            </div>
            <a href="admin_dashboard.php" class="btn btn-load" style="background: white; color: #1e293b; border: 1px solid #e2e8f0;">
                <i class="fas fa-arrow-left"></i> Dashboard
            </a>
        </header>

        <!-- Configuration Card -->
        <div class="attendance-card">
            <div class="filter-grid">
                <div class="input-group">
                    <label>Select Class</label>
                    <select id="class-select">
                        <option value="">Choose Class</option>
                        <?php for($i=1;$i<=12;$i++): ?>
                            <option value="<?= $i ?>">Class <?= $i ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="input-group">
                    <label>Select Batch</label>
                    <select id="batch-select">
                        <option value="">Choose Batch</option>
                        <option value="A">Batch A</option>
                        <option value="B">Batch B</option>
                        <option value="C">Batch C</option>
                        <option value="D">Batch D</option>
                    </select>
                </div>
                <div class="input-group">
                    <label>Session Date</label>
                    <input type="date" id="date-select" value="<?= date('Y-m-d') ?>">
                </div>
                <button class="btn btn-load" id="btn-fetch">
                    <i class="fas fa-sync-alt"></i> Fetch Students
                </button>
            </div>
        </div>

        <!-- Listing Area -->
        <div class="attendance-card listing-area" id="listing-card">
            <div class="bulk-actions">
                <button class="btn btn-bulk btn-present" onclick="setAll('P')">
                    <i class="fas fa-check-double rotate"></i> Mark All Present
                </button>
                <button class="btn btn-bulk btn-absent" onclick="setAll('A')">
                    <i class="fas fa-times-circle"></i> Mark All Absent
                </button>
            </div>

            <table class="student-table">
                <thead>
                    <tr>
                        <th width="70%">Student Identity</th>
                        <th width="30%" style="text-align: center;">Participation Status</th>
                    </tr>
                </thead>
                <tbody id="student-list-tbody">
                    <!-- Dynamic Rows -->
                </tbody>
            </table>

            <button class="btn btn-save" id="btn-save">
                <i class="fas fa-cloud-upload-alt"></i> Commit Attendance Ledger
            </button>
        </div>
    </div>

    <!-- Success Feedback Overlay -->
    <div id="toast">
        <i class="fas fa-circle-check"></i>
        <div>
            <h4 style="font-weight: 800; color: #1e293b;">Ledger Synchronized</h4>
            <p style="font-size: 13px; color: #64748b; margin-top: 2px;">Records have been recorded successfully.</p>
        </div>
    </div>

    <script>
        const btnFetch = document.getElementById('btn-fetch');
        const btnSave = document.getElementById('btn-save');
        const listingArea = document.getElementById('listing-card');
        const tbody = document.getElementById('student-list-tbody');
        const toast = document.getElementById('toast');

        let students = [];

        // Fetch Students
        btnFetch.onclick = async () => {
            const cls = document.getElementById('class-select').value;
            const bth = document.getElementById('batch-select').value;
            
            if (!cls || !bth) {
                alert("Please specify Class and Batch first.");
                return;
            }

            btnFetch.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Retrieving...';
            
            const formData = new FormData();
            formData.append('action', 'list_students');
            formData.append('class', cls);
            formData.append('batch', bth);

            try {
                const res = await fetch('api_attendance.php', { method: 'POST', body: formData });
                const result = await res.json();

                if (result.status === 'success') {
                    students = result.data;
                    renderStudents(students);
                    listingArea.style.display = 'block';
                    listingArea.scrollIntoView({ behavior: 'smooth' });
                } else {
                    alert(result.message);
                }
            } catch (e) {
                alert("System communication error.");
            } finally {
                btnFetch.innerHTML = '<i class="fas fa-sync-alt"></i> Fetch Students';
            }
        };

        function renderStudents(data) {
            tbody.innerHTML = data.map(s => `
                <tr class="student-row" data-id="${s.id}">
                    <td>
                        <div style="display: flex; align-items: center; gap: 15px;">
                            <div style="width: 40px; height: 40px; border-radius: 12px; background: #f1f5f9; display: flex; align-items: center; justify-content: center; color: #64748b; font-weight: 800;">
                                ${s.name.charAt(0)}
                            </div>
                            <span style="font-weight: 700; color: #334155;">${s.name}</span>
                        </div>
                    </td>
                    <td align="center">
                        <div class="toggle-group" data-student-id="${s.id}">
                            <button class="toggle-btn active P" onclick="setStatus(${s.id}, 'P', this)">PRESENT</button>
                            <button class="toggle-btn A" onclick="setStatus(${s.id}, 'A', this)">ABSENT</button>
                        </div>
                    </td>
                </tr>
            `).join('');
        }

        const attendanceData = {};

        function setStatus(id, status, el) {
            attendanceData[id] = status;
            const group = el.closest('.toggle-group');
            group.querySelectorAll('.toggle-btn').forEach(b => b.classList.remove('active'));
            el.classList.add('active');
        }

        function setAll(status) {
            students.forEach(s => {
                attendanceData[s.id] = status;
            });
            document.querySelectorAll('.toggle-btn').forEach(b => {
                if (b.classList.contains(status)) b.classList.add('active');
                else b.classList.remove('active');
            });
        }

        // Save Attendance
        btnSave.onclick = async () => {
            const cls = document.getElementById('class-select').value;
            const bth = document.getElementById('batch-select').value;
            const dte = document.getElementById('date-select').value;

            btnSave.innerHTML = '<i class="fas fa-sync fa-spin"></i> Committing Ledger...';

            const formData = new FormData();
            formData.append('action', 'save');
            formData.append('class', cls);
            formData.append('batch', bth);
            formData.append('date', dte);
            
            // Map statuses
            students.forEach(s => {
                formData.append(`status[${s.id}]`, attendanceData[s.id] || 'P');
            });

            try {
                const res = await fetch('api_attendance.php', { method: 'POST', body: formData });
                const result = await res.json();

                if (result.status === 'success') {
                    showToast();
                } else {
                    alert(result.message);
                }
            } catch (e) {
                alert("Critical ledger synchronization error.");
            } finally {
                btnSave.innerHTML = '<i class="fas fa-cloud-upload-alt"></i> Commit Attendance Ledger';
            }
        };

        function showToast() {
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 4000);
        }
    </script>
</body>
</html>
