<?php
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['ADMIN', 'TEACHER', 'PARENT'])) {
    echo json_encode(["status" => "error", "message" => "Unauthorized access."]);
    exit;
}

// Fixed path for organized structure
include '../includes/db.php';

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

if ($action === 'list') {
    $q = mysqli_query($conn, "
        SELECT u.id as user_id, u.name, s.class, s.roll_no, u.email, u.status
        FROM students s 
        JOIN users u ON s.user_id = u.id
        ORDER BY s.class, s.roll_no
    ");
    
    $data = [];
    if($q) while($r = mysqli_fetch_assoc($q)) $data[] = $r;
    echo json_encode(["status" => "success", "data" => $data]);
}
else if ($action === 'toggle_status') {
    if ($_SESSION['role'] !== 'ADMIN') exit;
    $id = (int)($_POST['user_id'] ?? 0);
    $status = (int)($_POST['status'] ?? 0);
    mysqli_query($conn, "UPDATE users SET status=$status WHERE id=$id");
    echo json_encode(["status" => "success"]);
}
else {
    echo json_encode(["status" => "error", "message" => "Invalid action."]);
}
?>
