<?php
session_start();
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['ADMIN', 'TEACHER'])) {
    header("Location: index.php");
    exit;
}
include 'includes/header.php'; 
?>

<!-- MAIN CONTENT -->
<div class="card-box" style="margin-top: 20px;">
    <div class="card-head">
        <h3>📋 Student Directory</h3>
        <p style="color: #94a3b8; font-weight: 600; font-size: 14px;">Total Students: <span id="studentCount">0</span></p>
    </div>

    <div style="overflow-x: auto;">
        <table style="width: 100%; border-collapse: separate; border-spacing: 0 10px;">
            <thead>
                <tr style="text-align: left; color: #94a3b8; font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 1px;">
                    <th style="padding: 15px;">Roll No</th>
                    <th style="padding: 15px;">Name</th>
                    <th style="padding: 15px;">Class</th>
                    <th style="padding: 15px;">Contact Email</th>
                    <th style="padding: 15px;">Status</th>
                </tr>
            </thead>
            <tbody id="studentTableBody">
                <tr>
                    <td colspan="5" style="text-align: center; padding: 40px; color: #94a3b8; font-weight: 700;">Fetching student data...</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const res = await fetch('api/api_students.php?action=list');
        const data = await res.json();

        if (data.status === 'success') {
            const table = document.getElementById('studentTableBody');
            const counter = document.getElementById('studentCount');
            table.innerHTML = '';
            counter.innerText = data.data.length;

            if (data.data.length === 0) {
                table.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 40px; color: #94a3b8; font-weight: 700;">No students found.</td></tr>';
                return;
            }

            data.data.forEach(s => {
                const tr = document.createElement('tr');
                tr.style.cssText = 'background: #f8fafc; transition: 0.3s; border-radius: 15px;';
                tr.innerHTML = `
                    <td style="padding: 15px; font-weight: 800; color: #4f46e5;">#${s.roll_no}</td>
                    <td style="padding: 15px; font-weight: 700; color: #1e293b;">${s.name}</td>
                    <td style="padding: 15px; font-weight: 600; color: #64748b;">Class ${s.class}</td>
                    <td style="padding: 15px; color: #94a3b8; font-size: 14px;">${s.email}</td>
                    <td style="padding: 15px;">
                        <span style="padding: 6px 12px; border-radius: 10px; font-size: 11px; font-weight: 800; background: ${s.status == 1 ? '#f0fdf4' : '#fef2f2'}; color: ${s.status == 1 ? '#10b981' : '#ef4444'}; text-transform: uppercase;">
                            ${s.status == 1 ? 'Active' : 'Inactive'}
                        </span>
                    </td>
                `;
                table.appendChild(tr);
            });
        }
    } catch (err) {
        console.error("Student list error:", err);
    }
});
</script>

<?php include 'includes/footer.php'; ?>
