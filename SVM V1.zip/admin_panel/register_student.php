<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Student | Sharda Vidhya Mandir</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #4F46E5;
            --primary-dark: #3730A3;
            --accent: #10B981;
            --danger: #EF4444;
            --bg-color: #F8FAFC;
            --glass-bg: rgba(255, 255, 255, 0.7);
            --glass-border: rgba(255, 255, 255, 0.2);
            --shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }

        * {
            margin: 0; padding: 0; box-sizing: border-box;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #EEF2FF 0%, #E0E7FF 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            overflow-x: hidden;
        }

        /* Animated Blobs */
        .blob {
            position: fixed;
            width: 400px; height: 400px;
            background: rgba(79, 70, 229, 0.15);
            filter: blur(100px);
            border-radius: 50%;
            z-index: -1;
            animation: float 20s infinite alternate;
        }
        @keyframes float {
            0% { transform: translate(-10%, -10%); }
            100% { transform: translate(20%, 20%); }
        }

        /* Navigation */
        nav {
            padding: 20px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.6);
            border-bottom: 1px solid var(--glass-border);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .logo { font-size: 24px; font-weight: 800; color: var(--primary); letter-spacing: -0.5px; }
        .nav-link { color: #64748B; text-decoration: none; font-weight: 600; display: flex; align-items: center; gap: 8px; transition: 0.3s; }
        .nav-link:hover { color: var(--primary); }

        /* Main Section */
        main {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 50px 20px;
        }

        .form-card {
            background: var(--glass-bg);
            backdrop-filter: blur(25px);
            border: 1px solid var(--glass-border);
            border-radius: 32px;
            padding: 45px;
            width: 100%;
            max-width: 850px;
            box-shadow: var(--shadow);
            animation: slideIn 0.8s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes slideIn {
            from { opacity: 0; transform: translateY(40px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .header { margin-bottom: 35px; }
        .header h1 { font-size: 32px; font-weight: 800; color: #1E293B; margin-bottom: 8px; }
        .header p { color: #64748B; font-size: 16px; }

        /* Form Grid */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }

        @media (max-width: 768px) { .form-grid { grid-template-columns: 1fr; } }

        .input-group { position: relative; margin-bottom: 5px; }
        .input-group label { display: block; font-size: 14px; font-weight: 600; color: #475569; margin-bottom: 10px; }
        
        .input-wrapper {
            position: relative;
            transition: 0.3s;
        }

        .input-wrapper i {
            position: absolute;
            left: 18px; top: 50%;
            transform: translateY(-50%);
            color: #94A3B8;
            transition: 0.3s;
        }

        input, select {
            width: 100%;
            padding: 14px 18px 14px 50px;
            background: white;
            border: 1.5px solid #E2E8F0;
            border-radius: 16px;
            font-size: 15px;
            color: #1E293B;
            outline: none;
            transition: 0.3s;
        }

        input:focus, select:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
        }

        input:focus + i, select:focus + i { color: var(--primary); }

        .btn-submit {
            grid-column: span 2;
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            border: none;
            padding: 18px;
            border-radius: 16px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            box-shadow: 0 10px 15px -3px rgba(79, 70, 229, 0.3);
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 20px 25px -5px rgba(79, 70, 229, 0.4);
        }

        .btn-submit:disabled { opacity: 0.7; cursor: not-allowed; }

        /* Feedback Toast */
        #feedback {
            grid-column: span 2;
            padding: 16px;
            border-radius: 16px;
            display: none;
            text-align: center;
            font-weight: 600;
            animation: fadeIn 0.4s ease;
            margin-top: 20px;
        }
        .success { background: #DCFCE7; color: #166534; border: 1px solid #BBF7D0; }
        .error { background: #FEE2E2; color: #991B1B; border: 1px solid #FECACA; }
    </style>
</head>
<body>
    <div class="blob"></div>

    <nav>
        <div class="logo">🏫 Sharda Vidhya Mandir</div>
        <a href="admin_dashboard.php" class="nav-link">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </nav>

    <main>
        <div class="form-card">
            <div class="header">
                <h1>Register New Student</h1>
                <p>Onboard a new student into the school management system.</p>
            </div>

            <form id="registrationForm" class="form-grid">
                <!-- Name -->
                <div class="input-group">
                    <label>Full Name</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user"></i>
                        <input type="text" name="name" placeholder="Enter student name" required>
                    </div>
                </div>

                <!-- Email -->
                <div class="input-group">
                    <label>Email Address</label>
                    <div class="input-wrapper">
                        <i class="fas fa-envelope"></i>
                        <input type="email" name="email" placeholder="example@school.com" required>
                    </div>
                </div>

                <!-- Password -->
                <div class="input-group">
                    <label>Default Password</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock"></i>
                        <input type="text" name="password" placeholder="Min. 8 characters" required>
                    </div>
                </div>

                <!-- Roll No -->
                <div class="input-group">
                    <label>Roll Number</label>
                    <div class="input-wrapper">
                        <i class="fas fa-id-card"></i>
                        <input type="text" name="roll_no" placeholder="Roll # (e.g. 101)" required>
                    </div>
                </div>

                <!-- Class -->
                <div class="input-group">
                    <label>Assigned Class</label>
                    <div class="input-wrapper">
                        <i class="fas fa-chalkboard"></i>
                        <select name="class" required>
                            <option value="">Choose Class</option>
                            <?php for ($i=1; $i<=12; $i++): ?>
                                <option value="<?= $i ?>">Class <?= $i ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                </div>

                <!-- Batch -->
                <div class="input-group">
                    <label>Batch / Section</label>
                    <div class="input-wrapper">
                        <i class="fas fa-users-rectangle"></i>
                        <select name="batch" required>
                            <option value="">Choose Batch</option>
                            <option value="A">Batch A</option>
                            <option value="B">Batch B</option>
                            <option value="C">Batch C</option>
                            <option value="D">Batch D</option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn-submit" id="submitBtn">
                    <i class="fas fa-plus"></i> Complete Registration
                </button>

                <div id="feedback"></div>
            </form>
        </div>
    </main>

    <script>
        const form = document.getElementById('registrationForm');
        const feedback = document.getElementById('feedback');
        const submitBtn = document.getElementById('submitBtn');

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Loading State
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            feedback.style.display = 'none';

            const formData = new FormData(form);

            try {
                const response = await fetch('api_register_student.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                feedback.style.display = 'block';
                if (data.success) {
                    feedback.className = 'success';
                    feedback.innerHTML = `<i class="fas fa-check-circle"></i> ${data.message}`;
                    form.reset();
                } else {
                    feedback.className = 'error';
                    feedback.innerHTML = `<i class="fas fa-exclamation-triangle"></i> ${data.message}`;
                }
            } catch (err) {
                feedback.style.display = 'block';
                feedback.className = 'error';
                feedback.innerHTML = '<i class="fas fa-wifi"></i> Connection error. Please try again.';
            } finally {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-plus"></i> Complete Registration';
            }
        });
    </script>
</body>
</html>
