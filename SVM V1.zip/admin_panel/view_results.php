<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
require_once 'db.php';

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$student_id = 0;
$student_name = "";

if ($role === 'STUDENT') {
    $stmt = mysqli_prepare($conn, "SELECT s.id, u.name FROM students s JOIN users u ON s.user_id = u.id WHERE s.user_id = ?");
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    $student_id = $row['id'] ?? 0;
    $student_name = $row['name'] ?? "Student";

} elseif ($role === 'PARENT') {
    $stmt = mysqli_prepare($conn, "SELECT s.id, u.name FROM parents p JOIN students s ON p.student_id = s.id JOIN users u ON s.user_id = u.id WHERE p.user_id = ?");
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    $student_id = $row['id'] ?? 0;
    $student_name = $row['name'] ?? "Child";
} else {
    header("Location: index.php");
    exit;
}

// Fetch results with prepared statement
$stmt_results = mysqli_prepare($conn, "SELECT * FROM results WHERE student_id = ? ORDER BY exam_date DESC, created_at DESC");
mysqli_stmt_bind_param($stmt_results, "i", $student_id);
mysqli_stmt_execute($stmt_results);
$results_q = mysqli_stmt_get_result($stmt_results);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Academic Results | School Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Outfit', sans-serif; }
    </style>
</head>
<body class="bg-[#f2f5f9] min-h-screen text-[#1a202c]">

<!-- NAVBAR -->
<div class="bg-white/80 backdrop-blur-xl border-b border-indigo-100 px-8 py-4 flex justify-between items-center sticky top-0 z-50">
    <div class="flex items-center gap-3">
        <div class="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-100">
            <span class="text-xl">🏆</span>
        </div>
        <div>
            <h1 class="text-lg font-bold leading-none">Performance Report</h1>
            <p class="text-[10px] uppercase tracking-wider font-extrabold text-indigo-500 mt-1">Academic Session 2024-25</p>
        </div>
    </div>
    <a href="<?= strtolower($role) ?>_dashboard.php" class="px-5 py-2 bg-slate-900 text-white rounded-xl text-sm font-bold hover:bg-slate-800 transition-all flex items-center gap-2">
        <span>←</span> Dashboard
    </a>
</div>

<div class="max-w-4xl mx-auto px-6 py-12">

    <!-- Hero Card -->
    <div class="bg-indigo-600 rounded-[2.5rem] p-10 text-white shadow-2xl shadow-indigo-200 mb-10 overflow-hidden relative">
        <div class="absolute -right-20 -top-20 w-80 h-80 bg-white/10 rounded-full blur-3xl"></div>
        <div class="absolute -left-20 -bottom-20 w-60 h-60 bg-indigo-400/20 rounded-full blur-3xl"></div>
        
        <div class="relative flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div>
                <p class="text-indigo-200 text-sm font-bold uppercase tracking-widest mb-2">Academic Profile</p>
                <h2 class="text-4xl font-extrabold mb-1"><?= htmlspecialchars($student_name) ?></h2>
                <div class="flex items-center gap-2 mt-4">
                    <span class="px-4 py-1.5 bg-white/20 rounded-full text-xs font-bold backdrop-blur-md">ID: STD-<?= str_pad($student_id, 4, '0', STR_PAD_LEFT) ?></span>
                    <span class="px-4 py-1.5 bg-indigo-500 rounded-full text-xs font-bold"><?= $role ?> VIEW</span>
                </div>
            </div>
            
            <div class="bg-white/10 backdrop-blur-xl border border-white/20 rounded-3xl p-6 text-center">
                <p class="text-indigo-100 text-[10px] font-bold uppercase tracking-widest mb-1">Overall Status</p>
                <span class="text-2xl font-black">EXCELLENT</span>
            </div>
        </div>
    </div>

    <!-- Results Feed -->
    <div class="space-y-6">
        <div class="flex items-center justify-between px-2">
            <h3 class="text-xl font-bold">Exam Records</h3>
            <span class="text-xs font-bold text-slate-400 uppercase tracking-widest">Total: <?= mysqli_num_rows($results_q) ?></span>
        </div>

        <?php if(mysqli_num_rows($results_q) > 0): ?>
            <?php while($r = mysqli_fetch_assoc($results_q)): 
                $perc = ($r['marks_obtained'] / $r['total_marks']) * 100;
                $isPass = $perc >= 40;
            ?>
            <div class="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 hover:shadow-xl hover:border-indigo-100 transition-all duration-300 group">
                <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                    <div class="flex gap-5 items-center">
                        <div class="w-14 h-14 rounded-2xl flex items-center justify-center font-black text-xl <?= $isPass ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600' ?> transition-colors group-hover:scale-110">
                            <?= ($marks_obtained > 0 ? '' : '') . round($perc) ?>%
                        </div>
                        <div>
                            <h4 class="text-lg font-bold text-slate-800"><?= htmlspecialchars($r['subject']) ?></h4>
                            <p class="text-sm font-medium text-slate-500 mt-0.5"><?= htmlspecialchars($r['exam_name']) ?></p>
                        </div>
                    </div>

                    <div class="flex items-center gap-8 w-full md:w-auto border-t md:border-t-0 pt-4 md:pt-0">
                        <div class="text-right">
                            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Score Detail</p>
                            <p class="text-lg font-black text-slate-800"><?= $r['marks_obtained'] ?> <span class="text-sm text-slate-400 font-medium">/ <?= $r['total_marks'] ?></span></p>
                        </div>
                        
                        <div class="flex flex-col items-center gap-1">
                            <div class="w-2.5 h-2.5 rounded-full <?= $isPass ? 'bg-emerald-500 shadow-emerald-200' : 'bg-rose-500 shadow-rose-200' ?> shadow-lg"></div>
                            <span class="text-[10px] font-extrabold uppercase tracking-widest <?= $isPass ? 'text-emerald-600' : 'text-rose-600' ?>">
                                <?= $isPass ? 'Pass' : 'Fail' ?>
                            </span>
                        </div>
                    </div>
                </div>
                
                <!-- Progress Line -->
                <div class="mt-6 w-full h-1.5 bg-slate-50 rounded-full overflow-hidden">
                    <div class="<?= $isPass ? 'bg-emerald-500' : 'bg-rose-500' ?> h-full rounded-full transition-all duration-1000 group-hover:opacity-80" style="width: <?= $perc ?>%"></div>
                </div>
                
                <div class="mt-4 flex justify-between items-center">
                    <span class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Exam Date: <?= date('d M Y', strtotime($r['exam_date'])) ?></span>
                    <button class="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors uppercase tracking-widest">Download PDF →</button>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="bg-white rounded-[2rem] py-20 text-center border-2 border-dashed border-slate-200">
                <div class="text-6xl mb-6 opacity-30">📂</div>
                <h3 class="text-xl font-bold text-slate-800">No results available</h3>
                <p class="text-slate-500 mt-2">Publishing academic reports in progress.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<footer class="text-center text-slate-400 text-xs py-10 mt-10">
    &copy; <?= date('Y') ?> School Management Performance Engine
</footer>

</body>
</html>
