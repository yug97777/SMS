<?php
require_once 'db.php';
$res = mysqli_query($conn, "DESC users");
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) {
        print_r($row);
    }
}
?>
