<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

require_once 'db.php';

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

/* Fetch notifications: Specific to user OR to the user's role OR to ALL */
$noti_stmt = mysqli_prepare($conn, "
    SELECT id, title, message, status, created_at
    FROM notifications
    WHERE (user_id = ? OR user_id IS NULL)
    AND (role = ? OR role = 'ALL')
    ORDER BY created_at DESC
");
mysqli_stmt_bind_param($noti_stmt, "is", $user_id, $role);
mysqli_stmt_execute($noti_stmt);
$notifications = mysqli_stmt_get_result($noti_stmt);

if (!$notifications) {
    die("SQL Error: " . mysqli_error($conn));
}

// Mark all as read when viewing (optional but good for UX)
$upd_stmt = mysqli_prepare($conn, "
    UPDATE notifications 
    SET status = 'READ' 
    WHERE (user_id = ? OR (user_id IS NULL AND role = ?))
    AND status = 'UNREAD'
");
mysqli_stmt_bind_param($upd_stmt, "is", $user_id, $role);
mysqli_stmt_execute($upd_stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Notification History</title>
<script src="https://cdn.tailwindcss.com"></script>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
    body { font-family: 'Inter', sans-serif; }
</style>
</head>

<body class="bg-gradient-to-br from-slate-50 to-indigo-50 min-h-screen">

<!-- HEADER -->
<div class="bg-white/80 backdrop-blur-md shadow-sm px-8 py-4 flex justify-between items-center sticky top-0 z-50">
    <div class="flex items-center gap-2">
        <span class="text-2xl">🔔</span>
        <h1 class="text-xl font-bold text-gray-800">Notifications</h1>
    </div>
    <a href="<?= strtolower($role) ?>_dashboard.php"
       class="px-5 py-2 bg-indigo-600 text-white rounded-xl font-semibold shadow-indigo-200 shadow-lg hover:bg-indigo-700 transition-all hover:scale-105">
        Back to Dashboard
    </a>
</div>

<div class="max-w-4xl mx-auto px-6 py-10">

<div class="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">

    <div class="p-8 border-b border-gray-50 flex justify-between items-center bg-gray-50/50">
        <h2 class="text-2xl font-bold text-gray-800">History</h2>
        <span class="px-4 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm font-medium">
            <?= mysqli_num_rows($notifications) ?> Total
        </span>
    </div>

    <div class="p-8">
    <?php if (mysqli_num_rows($notifications) > 0): ?>

    <div class="space-y-6">
    <?php while ($n = mysqli_fetch_assoc($notifications)): ?>

    <div class="p-6 rounded-2xl border transition-all hover:shadow-md
        <?= $n['status'] == 'UNREAD'
            ? 'border-indigo-200 bg-indigo-50/30'
            : 'border-gray-100 bg-white' ?>">

        <div class="flex justify-between items-start mb-2">
            <h3 class="font-bold text-lg text-gray-900">
                <?= htmlspecialchars($n['title'] ?: 'System Update') ?>
            </h3>
            <span class="text-xs font-medium text-gray-400 bg-gray-100 px-2 py-1 rounded">
                <?= date("d M Y • h:i A", strtotime($n['created_at'])) ?>
            </span>
        </div>

        <p class="text-gray-600 leading-relaxed">
            <?= nl2br(htmlspecialchars($n['message'])) ?>
        </p>

        <?php if ($n['status'] == 'UNREAD'): ?>
            <div class="mt-3 flex items-center gap-1">
                <span class="w-2 h-2 bg-indigo-600 rounded-full"></span>
                <span class="text-xs font-bold text-indigo-600 uppercase tracking-wider">New</span>
            </div>
        <?php endif; ?>

    </div>

    <?php endwhile; ?>
    </div>

    <?php else: ?>
    <div class="text-center py-20">
        <div class="text-6xl mb-4">📭</div>
        <h3 class="text-xl font-bold text-gray-800">All caught up!</h3>
        <p class="text-gray-500 mt-2">You don't have any notifications at the moment.</p>
    </div>
    <?php endif; ?>
    </div>

</div>
</div>

<footer class="text-center text-gray-400 text-sm py-10">
    &copy; <?= date('Y') ?> School Management System • Premium Edition
</footer>

</body>
</html>
