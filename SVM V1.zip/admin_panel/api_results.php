<?php
header('Content-Type: application/json');
session_start();

// Admin or Teacher protection
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['ADMIN', 'TEACHER'])) {
    echo json_encode(["status" => "error", "message" => "Unauthorized access."]);
    exit;
}

include 'db.php';

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

if ($action === 'list_meta') {
    // Get student list for the form
    $students = mysqli_query($conn, "SELECT s.id, u.name, s.roll_no FROM students s JOIN users u ON s.user_id = u.id ORDER BY u.name ASC");
    $list = [];
    while($r = mysqli_fetch_assoc($students)) {
        $list[] = $r;
    }
    echo json_encode(["status" => "success", "data" => $list]);
    exit;
}

else if ($action === 'list') {
    // Fetch last 15 results
    $query = "
        SELECT r.*, u.name as student_name 
        FROM results r 
        JOIN students s ON r.student_id = s.id 
        JOIN users u ON s.user_id = u.id 
        ORDER BY r.created_at DESC 
        LIMIT 15
    ";
    
    $result = mysqli_query($conn, $query);
    $data = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $row['percentage'] = ($row['marks_obtained'] / $row['total_marks']) * 100;
        $row['status'] = ($row['percentage'] >= 40) ? 'PASSED' : 'FAILED';
        $data[] = $row;
    }
    
    echo json_encode(["status" => "success", "data" => $data]);
}
else if ($action === 'save') {
    $student_id     = (int)($_POST['student_id'] ?? 0);
    $exam_name      = mysqli_real_escape_string($conn, trim($_POST['exam_name'] ?? ''));
    $subject        = mysqli_real_escape_string($conn, trim($_POST['subject'] ?? ''));
    $marks_obtained = (int)($_POST['marks_obtained'] ?? 0);
    $total_marks    = (int)($_POST['total_marks'] ?? 100);
    $exam_date      = mysqli_real_escape_string($conn, $_POST['exam_date'] ?? date('Y-m-d'));

    if (empty($student_id) || empty($exam_name) || empty($subject)) {
        echo json_encode(["status" => "error", "message" => "All fields are required."]);
        exit;
    }

    $stmt = mysqli_prepare($conn, "INSERT INTO results (student_id, exam_name, subject, marks_obtained, total_marks, exam_date) VALUES (?, ?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "issiis", $student_id, $exam_name, $subject, $marks_obtained, $total_marks, $exam_date);
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(["status" => "success", "message" => "Academic record published!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Database error: " . mysqli_error($conn)]);
    }
}
else if ($action === 'delete') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        $del = mysqli_query($conn, "DELETE FROM results WHERE id = $id");
        if ($del) {
            echo json_encode(["status" => "success", "message" => "Result record deleted."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Delete failed."]);
        }
    }
}
else {
    echo json_encode(["status" => "error", "message" => "Invalid action."]);
}
?>
