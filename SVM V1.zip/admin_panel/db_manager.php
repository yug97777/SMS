<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Nexus | Modern Admin Panel</title>
    
    <!-- Google Fonts & FontAwesome -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4338ca;
            --accent: #10b981;
            --danger: #ef4444;
            --bg-gradient: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            --glass: rgba(255, 255, 255, 0.05);
            --glass-border: rgba(255, 255, 255, 0.1);
            --text-glow: 0 0 10px rgba(99, 102, 241, 0.3);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Outfit', sans-serif;
            background: var(--bg-gradient);
            color: #f8fafc;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            overflow-x: hidden;
        }

        /* Animated Background Elements */
        .blob {
            position: fixed;
            width: 400px;
            height: 400px;
            background: rgba(99, 102, 241, 0.2);
            filter: blur(100px);
            border-radius: 50%;
            z-index: -1;
            animation: move 20s infinite alternate;
        }
        @keyframes move {
            from { transform: translate(-10%, -10%); }
            to { transform: translate(30%, 20%); }
        }

        .container {
            width: 100%;
            max-width: 900px;
            display: grid;
            grid-template-columns: 1fr 1.5fr;
            gap: 25px;
            animation: fadeIn 0.8s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Glass Cards */
        .card {
            background: var(--glass);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            border-radius: 24px;
            padding: 35px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            transition: all 0.3s ease;
        }

        .card:hover {
            border-color: rgba(99, 102, 241, 0.4);
            transform: translateY(-5px);
        }

        /* Status Sidebar */
        .sidebar { display: flex; flex-direction: column; gap: 20px; }
        
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 8px 16px;
            border-radius: 50px;
            font-size: 14px;
            font-weight: 600;
            background: rgba(255, 255, 255, 0.1);
        }

        .pulse {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--accent);
            box-shadow: 0 0 15px var(--accent);
            animation: pulse-ring 1.5s infinite;
        }

        @keyframes pulse-ring {
            0% { transform: scale(1); opacity: 1; }
            100% { transform: scale(2.5); opacity: 0; }
        }

        h1 { font-size: 32px; font-weight: 800; margin-bottom: 5px; background: linear-gradient(to right, #818cf8, #c084fc); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; }
        p.subtitle { color: #94a3b8; font-size: 15px; margin-bottom: 25px; }

        /* Forms */
        .form-group { margin-bottom: 20px; position: relative; }
        label { display: block; font-size: 13px; color: #94a3b8; margin-bottom: 8px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }
        
        .input-wrapper {
            position: relative;
            background: rgba(0, 0, 0, 0.2);
            border: 1px solid var(--glass-border);
            border-radius: 12px;
            transition: 0.3s;
        }
        
        .input-wrapper:focus-within {
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.15);
        }

        .input-wrapper i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
        }

        input {
            width: 100%;
            background: transparent;
            border: none;
            padding: 14px 15px 14px 45px;
            color: white;
            font-size: 15px;
            outline: none;
        }

        .btn {
            width: 100%;
            padding: 16px;
            border-radius: 12px;
            border: none;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            box-shadow: 0 10px 20px -5px rgba(99, 102, 241, 0.4);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 15px 25px -5px rgba(99, 102, 241, 0.5);
        }

        /* Result Panel */
        #result-display {
            margin-top: 20px;
            padding: 15px;
            border-radius: 12px;
            font-size: 14px;
            display: none;
            animation: slideUp 0.3s ease-out;
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .success { background: rgba(16, 185, 129, 0.1); color: #34d399; border: 1px solid rgba(16, 185, 129, 0.2); }
        .error { background: rgba(239, 68, 68, 0.1); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.2); }

        @media (max-width: 768px) {
            .container { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="blob"></div>
    
    <div class="container">
        <!-- Sidebar Info -->
        <div class="sidebar">
            <div class="card">
                <div class="status-badge">
                    <div class="pulse" id="status-pulse"></div>
                    <span id="status-text">SYSTEM ONLINE</span>
                </div>
                <h1 style="margin-top: 20px;">Database<br>Nexus</h1>
                <p class="subtitle">Securely configure your backend connection with real-time validation.</p>
                
                <div style="margin-top: 30px;">
                    <label>Monitoring</label>
                    <div style="display: flex; flex-direction: column; gap: 15px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="color: #94a3b8; font-size: 14px;">Latency</span>
                            <span style="font-weight: 600; color: #10b981;">12ms</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="color: #94a3b8; font-size: 14px;">MySQL Version</span>
                            <span style="font-weight: 600; color: #818cf8;">8.0.32</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card" style="padding: 25px;">
                <h3 style="font-size: 16px; margin-bottom: 15px;"><i class="fas fa-shield-halved" style="margin-right: 10px; color: var(--primary);"></i> Security Protocol</h3>
                <p style="font-size: 13px; color: #64748b; line-height: 1.6;">
                    Connection credentials are encrypted during transit. Always use restricted DB users for production environments.
                </p>
            </div>
        </div>

        <!-- Main Form -->
        <div class="card">
            <h2>Connection Settings</h2>
            <p class="subtitle">Enter your database credentials below.</p>
            
            <form id="db-form">
                <div class="form-group">
                    <label>Hostname</label>
                    <div class="input-wrapper">
                        <i class="fas fa-server"></i>
                        <input type="text" name="host" value="localhost" placeholder="e.g. localhost or 127.0.0.1">
                    </div>
                </div>

                <div class="grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Database User</label>
                        <div class="input-wrapper">
                            <i class="fas fa-user-shield"></i>
                            <input type="text" name="user" value="root" placeholder="Username">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Port</label>
                        <div class="input-wrapper">
                            <i class="fas fa-plug"></i>
                            <input type="number" name="port" value="3307" placeholder="3306">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <div class="input-wrapper">
                        <i class="fas fa-key"></i>
                        <input type="password" name="pass" placeholder="••••••••">
                    </div>
                </div>

                <div class="form-group">
                    <label>Database Name</label>
                    <div class="input-wrapper">
                        <i class="fas fa-database"></i>
                        <input type="text" name="dbname" value="admin_panel" placeholder="Target Database">
                    </div>
                </div>

                <button type="submit" class="btn btn-primary" id="submit-btn">
                    <i class="fas fa-plug-circle-check"></i>
                    Test Connection
                </button>
            </form>

            <div id="result-display"></div>
        </div>
    </div>

    <script>
        const form = document.getElementById('db-form');
        const display = document.getElementById('result-display');
        const btn = document.getElementById('submit-btn');

        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Show loading state
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            display.style.display = 'none';

            const formData = new FormData(form);
            formData.append('action', 'test');

            try {
                const response = await fetch('api_db.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();

                display.style.display = 'block';
                if (data.success) {
                    display.className = 'success';
                    display.innerHTML = `<i class="fas fa-circle-check"></i> ${data.message}`;
                    document.getElementById('status-pulse').style.background = '#10b981';
                    document.getElementById('status-pulse').style.boxShadow = '0 0 15px #10b981';
                    document.getElementById('status-text').innerText = 'CONNECTION STABLE';
                } else {
                    display.className = 'error';
                    display.innerHTML = `<i class="fas fa-circle-exclamation"></i> Error: ${data.message}`;
                    document.getElementById('status-pulse').style.background = '#ef4444';
                    document.getElementById('status-pulse').style.boxShadow = '0 0 15px #ef4444';
                    document.getElementById('status-text').innerText = 'CONNECTION FAILED';
                }
            } catch (err) {
                display.style.display = 'block';
                display.className = 'error';
                display.innerHTML = `<i class="fas fa-triangle-exclamation"></i> Server could not be reached.`;
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-plug-circle-check"></i> Test Connection';
            }
        });

        // Background Check
        async function checkStatus() {
            try {
                const res = await fetch('api_db.php?action=status');
                const data = await res.json();
                const pulse = document.getElementById('status-pulse');
                const text = document.getElementById('status-text');

                if (data.status === 'online') {
                    pulse.style.background = '#10b981';
                    text.innerText = 'DATABASE ONLINE';
                } else {
                    pulse.style.background = '#ef4444';
                    text.innerText = 'DATABASE OFFLINE';
                }
            } catch (e) {
                console.error("Status check failed");
            }
        }
        
        checkStatus();
    </script>
</body>
</html>
