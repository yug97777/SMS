<?php
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        "authenticated" => false,
        "message" => "No active session."
    ]);
    exit;
}

echo json_encode([
    "authenticated" => true,
    "user_id" => $_SESSION['user_id'],
    "name" => $_SESSION['name'],
    "role" => $_SESSION['role'],
    "email" => $_SESSION['email'] ?? ''
]);
?>
