CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role ENUM('ADMIN','TEACHER','STUDENT','PARENT') NOT NULL,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255),
  phone VARCHAR(15),
  status TINYINT DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE classes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  class_name VARCHAR(20),
  section VARCHAR(10)
);

CREATE TABLE subjects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  subject_name VARCHAR(50)
);

CREATE TABLE students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  class VARCHAR(20),
  roll_no INT,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role VARCHAR(20),
  name VARCHAR(100),
  email VARCHAR(100),
  password VARCHAR(50),
  status INT
);