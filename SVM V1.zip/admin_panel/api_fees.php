<?php
header('Content-Type: application/json');
session_start();

// Admin protection
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    echo json_encode(["status" => "error", "message" => "Unauthorized access."]);
    exit;
}

include 'db.php';

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

if ($action === 'stats') {
    $stats = [
        "total_collected" => mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) as s FROM fees WHERE status='PAID'"))['s'] ?? 0,
        "pending_dues" => mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(amount) as s FROM fees WHERE status='PENDING'"))['s'] ?? 0,
        "paid_count" => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM fees WHERE status='PAID'"))['c'] ?? 0,
        "pending_count" => mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as c FROM fees WHERE status='PENDING'"))['c'] ?? 0
    ];
    echo json_encode(["status" => "success", "data" => $stats]);
    exit;
}

if ($action === 'list_meta') {
    $students = mysqli_query($conn, "SELECT s.id, u.name, s.roll_no FROM students s JOIN users u ON s.user_id = u.id ORDER BY u.name ASC");
    $list = [];
    while($r = mysqli_fetch_assoc($students)) $list[] = $r;
    echo json_encode(["status" => "success", "data" => $list]);
    exit;
}

else if ($action === 'list') {
    // Fetch fee records
    $query = "
        SELECT 
            f.id,
            u.name AS student_name,
            f.amount,
            f.status,
            f.razorpay_payment_id,
            f.payment_date
        FROM fees f
        JOIN students s ON f.student_id = s.id
        JOIN users u ON s.user_id = u.id
        ORDER BY f.payment_date DESC
    ";
    
    $result = mysqli_query($conn, $query);
    $fees = [];
    
    while ($row = mysqli_fetch_assoc($result)) {
        $row['formatted_date'] = $row['payment_date'] ? date("d M Y, h:i A", strtotime($row['payment_date'])) : '-';
        $row['formatted_amount'] = '₹' . number_format($row['amount']);
        $fees[] = $row;
    }
    
    echo json_encode(["status" => "success", "data" => $fees]);
}
else if ($action === 'delete') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        $del = mysqli_query($conn, "DELETE FROM fees WHERE id = $id");
        if ($del) {
            echo json_encode(["status" => "success", "message" => "Record deleted."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Delete failed."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid ID."]);
    }
}
else if ($action === 'save') {
    $student_id = (int)($_POST['student_id'] ?? 0);
    $amount     = (float)($_POST['amount'] ?? 0);
    $due_date   = mysqli_real_escape_string($conn, $_POST['due_date'] ?? date('Y-m-d'));

    if (empty($student_id) || empty($amount) || empty($due_date)) {
        echo json_encode(["status" => "error", "message" => "All fields are required."]);
        exit;
    }

    // 🛡️ Prepared Statement
    $stmt_fee = mysqli_prepare($conn, "INSERT INTO fees (student_id, amount, due_date, status) VALUES (?, ?, ?, 'PENDING')");
    mysqli_stmt_bind_param($stmt_fee, "ids", $student_id, $amount, $due_date);
    
    if (mysqli_stmt_execute($stmt_fee)) {
        // 🔔 Notification for parents
        $title = "New Fee Added";
        $message = "A new fee of ₹$amount has been added. Due date: " . date('d M Y', strtotime($due_date));
        $role = "PARENT";

        $stmt_noti = mysqli_prepare($conn, "INSERT INTO notifications (title, message, role, status) VALUES (?, ?, ?, 'UNREAD')");
        mysqli_stmt_bind_param($stmt_noti, "sss", $title, $message, $role);
        mysqli_stmt_execute($stmt_noti);

        echo json_encode(["status" => "success", "message" => "Fee added successfully!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Database error: " . mysqli_stmt_error($stmt_fee)]);
    }
}
else {
    echo json_encode(["status" => "error", "message" => "Invalid action."]);
}
?>
