<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'TEACHER') {
    header("Location: admin_login.php");
    exit;
}

include 'db.php';

$date  = $_POST['date'] ?? '';
$statusData = $_POST['status'] ?? [];

if(!$date || empty($statusData)){
    die("Invalid data submitted.");
}

// 🛡️ Start Transaction for bulk performance
mysqli_begin_transaction($conn);

try {
    // 🛡️ Prepare statements for reuse
    $stmt_check = mysqli_prepare($conn, "SELECT id FROM attendance WHERE student_id = ? AND date = ?");
    $stmt_upd   = mysqli_prepare($conn, "UPDATE attendance SET status = ? WHERE student_id = ? AND date = ?");
    $stmt_ins   = mysqli_prepare($conn, "INSERT INTO attendance (student_id, date, status) VALUES (?, ?, ?)");

    foreach($statusData as $student_id => $status){
        
        // Check existence
        mysqli_stmt_bind_param($stmt_check, "is", $student_id, $date);
        mysqli_stmt_execute($stmt_check);
        $res = mysqli_stmt_get_result($stmt_check);

        if(mysqli_num_rows($res) > 0){
            // UPDATE
            mysqli_stmt_bind_param($stmt_upd, "sis", $status, $student_id, $date);
            mysqli_stmt_execute($stmt_upd);
        } else {
            // INSERT
            mysqli_stmt_bind_param($stmt_ins, "iss", $student_id, $date, $status);
            mysqli_stmt_execute($stmt_ins);
        }
    }

    mysqli_commit($conn);
    header("Location: mark_attendance.php?success=1");
    exit;

} catch (Exception $e) {
    mysqli_rollback($conn);
    die("Attendance save failed: " . $e->getMessage());
}
?>