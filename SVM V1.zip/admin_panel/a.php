<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    header("Location: admin_login.php");
    exit;
}

include 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Attendance Overview | Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<script src="https://cdn.tailwindcss.com"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">

<style>
.card {
    background: white;
    border-radius: 20px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.08);
}
</style>
</head>

<body class="bg-gradient-to-br from-indigo-50 to-blue-100 min-h-screen">

<!-- NAVBAR -->
<div class="bg-white shadow px-8 py-4 flex justify-between items-center sticky top-0 z-10">
    <h1 class="text-2xl font-bold text-indigo-600 flex items-center gap-2">
        📊 Attendance Overview
    </h1>
    <a href="admin_dashboard.php"
       class="px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition">
        Dashboard
    </a>
</div>

<div class="max-w-6xl mx-auto px-6 py-10">

<div class="card p-8">

<h2 class="text-xl font-bold text-gray-800 mb-6">
    Student Attendance Records
</h2>

<div class="overflow-x-auto">
<table class="w-full text-sm border-collapse">

<thead>
<tr class="bg-indigo-600 text-white text-left">
    <th class="p-4 rounded-l-xl">Date</th>
    <th class="p-4">Student Name</th>
    <th class="p-4 text-center rounded-r-xl">Status</th>
</tr>
</thead>

<tbody>
<?php
$q = mysqli_query($conn, "
    SELECT 
        a.date,
        u.name AS student_name,
        a.status
    FROM attendance a
    JOIN students s ON a.student_id = s.id
    JOIN users u ON s.user_id = u.id
    ORDER BY a.date DESC
");

if(!$q){
    echo "<tr><td colspan='3' class='p-6 text-red-600 text-center font-bold'>
            SQL ERROR: ".mysqli_error($conn)."
          </td></tr>";
}
elseif(mysqli_num_rows($q) == 0){
    echo "<tr><td colspan='3' class='p-6 text-center text-gray-500'>
            No attendance records found.
          </td></tr>";
}
else{
    while($r = mysqli_fetch_assoc($q)){
?>
<tr class="border-b hover:bg-indigo-50 transition">
    <td class="p-4 text-gray-700">
        <?= htmlspecialchars($r['date']) ?>
    </td>
    <td class="p-4 font-semibold text-gray-800">
        <?= htmlspecialchars($r['student_name']) ?>
    </td>
    <td class="p-4 text-center font-bold">
        <?php if($r['status'] === 'P'): ?>
            <span class="px-4 py-1 rounded-full bg-green-100 text-green-700">
                Present
            </span>
        <?php else: ?>
            <span class="px-4 py-1 rounded-full bg-red-100 text-red-700">
                Absent
            </span>
        <?php endif; ?>
    </td>
</tr>
<?php }} ?>
</tbody>

</table>
</div>

</div>
</div>

<!-- FOOTER -->
<div class="text-center text-gray-500 text-sm py-6">
    © <?php echo date('Y'); ?> School Management System
</div>

</body>
</html>
