<?php
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    echo json_encode(["status" => "error", "message" => "Unauthorized access."]);
    exit;
}

include 'db.php';

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

if ($action === 'list') {
    $q = mysqli_query($conn, "
        SELECT u.id as user_id, u.name, t.qualification, t.subject, u.email, u.status
        FROM teachers t 
        JOIN users u ON t.user_id = u.id
        ORDER BY u.name ASC
    ");
    
    $data = [];
    while($r = mysqli_fetch_assoc($q)) $data[] = $r;
    echo json_encode(["status" => "success", "data" => $data]);
}
else if ($action === 'toggle_status') {
    $id = (int)($_POST['user_id'] ?? 0);
    $status = (int)($_POST['status'] ?? 0);
    mysqli_query($conn, "UPDATE users SET status=$status WHERE id=$id");
    echo json_encode(["status" => "success"]);
}
else {
    echo json_encode(["status" => "error", "message" => "Invalid action."]);
}
?>
