# 🏫 Sharda Vidhya Mandir Sancul — School Management System

A full-stack, role-based School Management System built with **PHP**, **MySQL**, **HTML5**, **Vanilla CSS**, and **JavaScript (Fetch API)**. Designed for the daily operations of **Sharda Vidhya Mandir Sancul** — managing students, teachers, parents, attendance, fees, results, notifications, and study materials from a single platform.

---

## ✨ Key Features

- **Multi-Role Access** — Admin, Teacher, Student, Parent with role-specific dashboards
- **Modern Frontend** — Glassmorphism UI, micro-animations, responsive design
- **AJAX Architecture** — All operations via Fetch API → JSON APIs (no page reloads)
- **Attendance System** — Teachers mark attendance; students & parents track it live
- **Fee Management** — Add fee records, track payments, Razorpay integration for parents
- **Results Engine** — Publish exam scores with auto pass/fail calculation
- **Broadcast Center** — Send targeted notifications to students, parents, or staff
- **Study Materials** — Upload and share notes & resources class-wise
- **Database Nexus** — Built-in connection tester and health monitor

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Frontend | HTML5, Vanilla CSS, JavaScript (Fetch API) |
| Backend | PHP 8.x (mysqli) |
| Database | MySQL (XAMPP, Port 3307) |
| Server | Apache (XAMPP) |
| Fonts | Google Fonts (Outfit, Plus Jakarta Sans, Space Grotesk) |
| Icons | Font Awesome 6.x |

---

## 🚀 Setup & Installation

1. Install **XAMPP** and start **Apache** + **MySQL**
2. Clone or copy `admin_panel/` into `C:\xampp\htdocs\`
3. Open **phpMyAdmin** → Create database: `admin_panel`
4. Import the SQL schema or run the migration scripts
5. Visit: `http://localhost/admin_panel/`

---

## 👥 User Roles

| Role | Dashboard | Key Actions |
|---|---|---|
| **Admin** | `admin_dashboard.php` | Register users, manage fees/results/notifications, DB health |
| **Teacher** | `teacher_dashboard.php` | Mark attendance, add results, upload materials, send notices |
| **Student** | `student_dashboard.php` | View attendance, results, materials, notifications |
| **Parent** | `parent_dashboard.php` | Monitor child's attendance, pay fees, view results |

---

## 📂 Project Structure

```
admin_panel/
├── index.php                    # Login Page
├── db.php                       # Database Connection
│
├── admin_dashboard.php          # Admin Hub
├── teacher_dashboard.php        # Teacher Hub
├── student_dashboard.php        # Student Hub
├── parent_dashboard.php         # Parent Hub
│
├── register_student.php         # Student Registration UI
├── register_teacher.php         # Teacher Onboarding UI (Multi-Step)
├── register_parent.php          # Parent Registration UI
│
├── mark_attendance.php          # Attendance Marking UI
├── fees_management.php          # Finance Dashboard UI
├── admin_results.php            # Results Dashboard UI
├── send_notification.php        # Broadcast Center UI
├── db_manager.php               # Database Nexus UI
│
├── api_register_student.php     # Student Registration API
├── api_register_teacher.php     # Teacher Registration API
├── api_register_parent.php      # Parent Registration API
├── api_attendance.php           # Attendance API
├── api_fees.php                 # Fees API
├── api_results.php              # Results API
├── api_notifications.php        # Notification API
├── api_db.php                   # Database Health API
│
└── README.md                    # This file
```

---

## 🔒 Security

- Passwords hashed with `bcrypt` via `password_hash()`
- Session-based auth with role guards on every page
- SQL injection protection via prepared statements
- XSS prevention with `htmlspecialchars()`
- Database transactions with rollback support

---

## 📄 License

This project is developed for **Sharda Vidhya Mandir Sancul** for educational and institutional use.
