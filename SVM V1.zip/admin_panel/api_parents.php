<?php
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'ADMIN') {
    echo json_encode(["status" => "error", "message" => "Unauthorized access."]);
    exit;
}

include 'db.php';

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

if ($action === 'list') {
    $q = mysqli_query($conn, "
        SELECT 
            p.id as parent_id,
            u.id as user_id,
            u.name as parent_name,
            u.email,
            p.phone,
            us.name as student_name,
            s.roll_no as student_roll,
            u.status
        FROM parents p
        JOIN users u ON p.user_id = u.id
        JOIN students s ON p.student_id = s.id
        JOIN users us ON s.user_id = us.id
        ORDER BY u.name ASC
    ");
    
    $data = [];
    while($r = mysqli_fetch_assoc($q)) $data[] = $r;
    echo json_encode(["status" => "success", "data" => $data]);
}
else if ($action === 'list_meta') {
    $students = mysqli_query($conn, "SELECT s.id, u.name, s.roll_no FROM students s JOIN users u ON s.user_id = u.id ORDER BY u.name ASC");
    $list = [];
    while($r = mysqli_fetch_assoc($students)) $list[] = $r;
    echo json_encode(["status" => "success", "data" => $list]);
    exit;
}
else if ($action === 'toggle_status') {
    $id = (int)($_POST['user_id'] ?? 0);
    $status = (int)($_POST['status'] ?? 0);
    mysqli_query($conn, "UPDATE users SET status=$status WHERE id=$id");
    echo json_encode(["status" => "success"]);
}
else {
    echo json_encode(["status" => "error", "message" => "Invalid action."]);
}
?>
