<?php
session_start();
// Auto-redirect if already logged in
if (isset($_SESSION['role'])) {
    $dashboards = [
        'ADMIN'   => 'admin_dashboard.php',
        'TEACHER' => 'teacher_dashboard.php',
        'STUDENT' => 'student_dashboard.php',
        'PARENT'  => 'parent_dashboard.php'
    ];
    header("Location: " . ($dashboards[$_SESSION['role']] ?? 'index.php'));
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | Sharda Vidhya Mandir</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/auth.css">
</head>
<body>

<div class="login-container">
    <div class="login-left">
        <img src="images.jpg" style="width:120px; border-radius:30px;">
        <h2 style="font-size:24px; font-weight:800; line-height:1.2;">Sharda Vidhya Mandir<br><span style="font-size:16px; opacity:0.8; font-weight:600;">Sancul — Portal</span></h2>
    </div>

    <div class="login-right">
        <h2>Secure Login</h2>

        <div id="message-box"></div>

        <form id="loginForm">
            <div class="form-group">
                <input type="text" name="username" placeholder="Email or Username" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" class="login-btn">Log In</button>
        </form>
        <p style="margin-top:25px; font-size:12px; color:#94a3b8; font-weight:700; text-align:center;">
           © <?= date('Y') ?> System Security Active
        </p>
    </div>
</div>

<script>
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const msgBox = document.getElementById('message-box');
    const formData = new FormData(this);

    msgBox.style.display = 'block';
    msgBox.className = 'success-msg';
    msgBox.innerHTML = 'Verifying credentials...';

    // Point to new API location
    fetch('admin_login.php', { // Keeping original name for now, but will migrate later
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'success') {
            msgBox.className = 'success-msg';
            msgBox.innerHTML = 'Login successful!';
            setTimeout(() => window.location.href = data.redirect, 1000);
        } else {
            msgBox.className = 'error-msg';
            msgBox.innerHTML = data.message;
        }
    })
    .catch(() => {
        msgBox.className = 'error-msg';
        msgBox.innerHTML = 'Login server connection lost.';
    });
});
</script>

</body>
</html>
