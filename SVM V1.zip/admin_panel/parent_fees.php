<?php
session_start();
include 'db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'PARENT') {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch fee records
$stmt = mysqli_prepare($conn, "
    SELECT f.id, f.amount, f.due_date, f.status
    FROM fees f
    JOIN parents p ON f.student_id = p.student_id
    WHERE p.user_id = ?
");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$q = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fee Payment | Parent Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50 min-h-screen">

<nav class="bg-white shadow px-8 py-4 flex justify-between items-center sticky top-0 z-50">
    <h1 class="text-xl font-bold text-indigo-700 flex items-center gap-2">
        <i class="fas fa-wallet"></i> Fee Management
    </h1>
    <a href="parent_dashboard.php" class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition">
        Dashboard
    </a>
</nav>

<main class="max-w-5xl mx-auto py-12 px-6">
    <div class="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
        <div class="bg-indigo-600 p-8 text-white">
            <h2 class="text-2xl font-bold">Outstanding Fees</h2>
            <p class="text-indigo-100 opacity-90">Pay your ward's school fees securely via Razorpay.</p>
        </div>

        <div class="p-8">
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead>
                        <tr class="text-gray-400 text-xs font-black uppercase tracking-widest border-b border-gray-100">
                            <th class="pb-4 px-4 text-center">Receipt #</th>
                            <th class="pb-4">Amount Due</th>
                            <th class="pb-4">Due Date</th>
                            <th class="pb-4">Status</th>
                            <th class="pb-4 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-50">
                        <?php if(mysqli_num_rows($q) > 0): ?>
                            <?php while($f = mysqli_fetch_assoc($q)): ?>
                                <tr class="hover:bg-gray-50/50 transition">
                                    <td class="py-5 px-4 text-center font-mono text-gray-400">#<?= $f['id'] ?></td>
                                    <td class="py-5">
                                        <span class="text-lg font-bold text-gray-800">₹<?= number_format($f['amount'], 2) ?></span>
                                    </td>
                                    <td class="py-5 text-gray-600 font-medium"><?= date('d M Y', strtotime($f['due_date'])) ?></td>
                                    <td class="py-5">
                                        <?php if($f['status'] === 'PAID'): ?>
                                            <span class="px-3 py-1 bg-green-100 text-green-700 rounded-full text-[10px] font-black uppercase">PAID</span>
                                        <?php else: ?>
                                            <span class="px-3 py-1 bg-rose-100 text-rose-700 rounded-full text-[10px] font-black uppercase">PENDING</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-5 text-right">
                                        <?php if($f['status'] === 'PENDING'): ?>
                                            <button onclick="payFee(<?= $f['id'] ?>, <?= $f['amount'] ?>)" 
                                                class="px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-indigo-200 hover:bg-indigo-700 hover:-translate-y-0.5 transition active:scale-95">
                                                Pay Now
                                            </button>
                                        <?php else: ?>
                                            <button disabled class="px-6 py-2 bg-gray-100 text-gray-400 rounded-xl font-bold text-sm cursor-not-allowed">
                                                No Dues
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="py-20 text-center text-gray-400 italic">No fee records found for your account.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<script>
function payFee(feeId, amount) {
    const options = {
        key: "rzp_test_YOUR_KEY_HERE", // ⚠️ Replace with real key
        amount: amount * 100, // Amount in paisa
        currency: "INR",
        name: "School Management System",
        description: "School Fee Payment",
        handler: function (response) {
            // Payment success!
            window.location.href = `payment_success.php?fee_id=${feeId}&payment_id=${response.razorpay_payment_id}`;
        },
        prefill: {
            name: "<?= $_SESSION['name'] ?>",
            email: "<?= $_SESSION['email'] ?? '' ?>"
        },
        theme: {
            color: "#4f46e5"
        }
    };
    const rzp = new Razorpay(options);
    rzp.open();
}
</script>

<footer class="text-center py-10 text-gray-400 text-xs font-bold uppercase tracking-widest">
    &copy; <?= date('Y') ?> Secure Payment Services
</footer>

</body>
</html>
