<?php
session_start();
include 'db.php';
$student_id = $_SESSION['user_id'];
?>
<table>
<?php
$q = mysqli_query($conn,"
SELECT date,status FROM attendance WHERE student_id='$student_id'
");
while($r=mysqli_fetch_assoc($q)){
    echo "<tr><td>{$r['date']}</td><td>{$r['status']}</td></tr>";
}
?>
</table>
