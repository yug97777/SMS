    </main>

    <!-- Shared Scripts -->
    <script>
        // Global logic can go here
        window.addEventListener('load', () => {
             // Example: Auto-hide loaders
             const loader = document.getElementById('loader');
             if (loader) setTimeout(() => loader.style.display = 'none', 500);
        });
    </script>
</body>
</html>
