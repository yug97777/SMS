# 📂 Project Reorganization Plan

This guide tracks the progress of organizing the **Sharda Vidhya Mandir Sancul** codebase into a modern, modular structure.

## 🏗️ New Directory Structure

```text
admin_panel/
├── api/                # JSON Endpoint Files (Logic)
│   ├── api_admin_stats.php ✅
│   ├── api_check_session.php ✅
│   └── api_students.php ✅
├── assets/             # Static Resources
│   ├── css/
│   │   ├── style.css   # Shared Dashboard Styles ✅
│   │   └── auth.css    # Unified Login Styles ✅
│   └── img/            # Site Assets (Move images.jpg here)
├── includes/           # Shared PHP Logic & Templates
│   ├── db.php          # Database Connection ✅
│   ├── header.php      # Main Sidebar & <head> ✅
│   └── footer.php      # Closing tags & global JS ✅
├── setup/              # Configuration & Migration Scripts
└── index.php           # Entry Point (Updated to new design) ✅
```

## ✅ Completed Tasks

1.  **Refactor Design**: Extracted all CSS into `assets/css/` to reduce redundancy.
2.  **Shared Layouts**: Implementation of `header.php` and `footer.php` allows updates to navigation or theme in ONE place instead of 60.
3.  **Core Dashboard**: Upgraded `admin_dashboard.php` to use the premium design and shared components.
4.  **Student Management**: Migrated `students_list.php` and its API to the new architecture.
5.  **Secure Login**: Cleaned up `index.php` for a premium first impression.

## 🚀 Recommended Next Steps

### 1. File Cleanup (Manual Action Required)
Please manually DELETE (or move to a backup folder) the following redundant files from the root search results:

- [ ] `db.php` (Logic moved to `includes/db.php`)
- [ ] `api_admin_stats.php` (Moved to `api/`)
- [ ] `api_check_session.php` (Moved to `api/`)
- [ ] `api_students.php` (Moved to `api/`)
- [ ] `admin_dashboard.html` (Redundant, use `.php` version)
- [ ] `students_list.html` (Redundant, use `.php` version)
- [ ] `a.php`, `d.php`, `o.php`, `p.txt` (Development junk)

### 2. Move Remaining APIs
Follow the pattern established in `api/api_students.php` to move the remaining `api_*.php` files. Remember to update the `include 'db.php'` to `include '../includes/db.php'`.

### 3. Update Other Pages
Convert other pages (like `attendance_overview.php` or `register_teacher.php`) to use:
```php
<?php include 'includes/header.php'; ?>
<!-- Content -->
<?php include 'includes/footer.php'; ?>
```
