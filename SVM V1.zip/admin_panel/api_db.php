<?php
header('Content-Type: application/json');

// Function to test mysqli connection
function test_db($host, $user, $pass, $dbname, $port = 3306) {
    try {
        $conn = @mysqli_connect($host, $user, $pass, $dbname, $port);
        if ($conn) {
            mysqli_close($conn);
            return ["success" => true, "message" => "Connection Successful!"];
        } else {
            return ["success" => false, "message" => mysqli_connect_error()];
        }
    } catch (Exception $e) {
        return ["success" => false, "message" => $e->getMessage()];
    }
}

// Check action
$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'test') {
    $host   = $_POST['host'] ?? 'localhost';
    $user   = $_POST['user'] ?? 'root';
    $pass   = $_POST['pass'] ?? '';
    $dbname = $_POST['dbname'] ?? '';
    $port   = (int)($_POST['port'] ?? 3306);
    
    echo json_encode(test_db($host, $user, $pass, $dbname, $port));
} 
else if ($action === 'status') {
    // Test current db.php
    if (file_exists('db.php')) {
        include 'db.php';
        if (isset($conn) && $conn) {
            echo json_encode(["status" => "online", "database" => $dbname]);
        } else {
            echo json_encode(["status" => "offline", "error" => "Connection failed"]);
        }
    } else {
        echo json_encode(["status" => "missing", "error" => "db.php not found"]);
    }
}
else {
    echo json_encode(["success" => false, "message" => "Invalid Action"]);
}
?>
