# API Folder
This folder contains all the JSON endpoints for the school management system.
